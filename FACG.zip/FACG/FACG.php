<?php
/*
Plugin Name: FACG美化插件
Plugin URI: https://facg.top/
Description: 由枫影开发的子比主题美化插件，为子比主题提供更多的扩展功能。主题源码有详细的注释，支持二次开发。使用盗版主题会存在各种未知风险。支持正版，从我做起！
Version: 3.3
Author: 枫影
Author URI: https://facg.top/
*/

//主题核心变量 修改就爆炸！
if (!function_exists('FACG')) {

	function FACG($option = '', $default = null)
	{
		$options = get_option('FACG'); // Attention: Set your unique id of the framework
		return (isset($options[$option])) ? $options[$option] : $default;
	}
}
define('FACG_TEMPLATE_DIRECTORY_URI',  plugin_dir_path( __FILE__ )); //本插件
define('FACGurl',  plugins_url('',__FILE__)); //本插件URL
define('FACGpath', dirname(__DIR__) . '/'); //插件的路径
require plugin_dir_path(__FILE__) .'inc/inc.php';
 
 //获取版本号
function Plugin_Version($dete)
{
  // 获取当前插件主文件路径
  	if( ! function_exists('get_plugin_data') ){
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}
	$plugin_data = get_plugin_data( __FILE__ );

    return $plugin_data[$dete];

}

require 'update/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://fymoe915.github.io/FACG/info.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'FACG'
);

//插件配置选项
add_filter( 'plugin_action_links', 'wpmdr_add_action_plugin', 10, 5 );

function wpmdr_add_action_plugin( $actions, $plugin_file ) 
{
   static $plugin;
   if (!isset($plugin))
		$plugin = plugin_basename(__FILE__);
   if ($plugin == $plugin_file) {
	  $site_link = array('settings' => '<a style="color: green;" href="/wp-admin/admin.php?page=FACG">配置插件</a>');
      $settings = array('setting' => '<a style="color: #FCB214;" href="https://facg.top/" target="_blank">帮助</a>');
      $actions = array_merge($settings, $actions);
      $actions = array_merge($site_link, $actions);
   }
   return $actions;
}
//插件启动时执行函数
 register_activation_hook(__FILE__, 'FACG_plugin_activate');
add_action('admin_init', 'FACG_plugin_redirect');
function FACG_plugin_activate() {
    add_option('FACG_plugin_do_redirect', true);
}
function FACG_plugin_redirect() {
    if (get_option('FACG_plugin_do_redirect', false)) {
        delete_option('FACG_plugin_do_redirect');
        wp_redirect(admin_url( '/admin.php?page=FACG' ));
    }
}
