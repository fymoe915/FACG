<?php


//载入文件
$require_once = array(
    'inc/codestar-framework/codestar-framework.php',
    'inc/csf-framework/classes/zib-csf.class.php',
    'inc/options/options.php',
    'inc/options/admin-options.php',
    'inc/options/functions.php',
	'plugin/weihu.php',
);

foreach ($require_once as $require) {
    require FACG_TEMPLATE_DIRECTORY_URI.$require ;
}
