<?php

if (class_exists('CSF')) {
$prefix = 'FACG';
 function FACG_new_badge()
{
    return array(
        'theme_footer' => '<badge>初一小盏</badge>',
        'theme_footer_v2' => '<badge>初一小盏</badge>',
    );
}
$img = '/wp-content/plugins/FACG/img/';
$vxras_music_images = '/wp-content/plugins/FACG/images/';
$new_badge = FACG_new_badge();
$new_badge_footer = $new_badge['theme_footer'];
$new_badge_footer_v2 = $new_badge['theme_footer_v2'];
//开始构建
    CSF::createOptions($prefix, array(
        'menu_title' => '枫影美化插件',
        'menu_slug' => 'FACG',
        'framework_title' => '枫影美化插件',
        'show_in_customizer' => true,
        'footer_text'  => '枫影美化插件',
        'theme' => 'light'
    ));
	
//全局&美化
    CSF::createSection($prefix, array(
        'id'    => 'global',
        'title' => '全局&美化',
        'icon'  => 'fa fa-bullseye'
    ));
	
	//鼠标皮肤
	CSF::createSection($prefix, array(
    'parent'      => 'global',
	'title'       => '鼠标皮肤',
	'icon'        => 'fa fa-file-text',
	'fields'      => array(
        array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
		),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'shubiao1.png"><img src="'.$img.'shubiao2.png">',
            'label'   => '【蓝色精灵】',
            'id'      => 'shubiao',
            'type'    => 'switcher',
            'default' => false
        ) ,
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr1.png"><img src="'.$img.'arr2.png">',
            'label'   => '【寒雨剑锋】',
            'class'   => 'compact',
            'id'      => 'shubiao2',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr3.png"><img src="'.$img.'arr4.png">',
            'label'   => '【幽灵琥珀】',
            'class'   => 'compact',
            'id'      => 'shubiao3',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr5.png"><img src="'.$img.'arr6.png">',
            'label'   => '【红蓝对决】',
            'class'   => 'compact',
            'id'      => 'shubiao4',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr7.png"><img src="'.$img.'arr8.png">',
            'label'   => '【返璞风筝】',
            'class'   => 'compact',
            'id'      => 'shubiao5',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr9.png"><img src="'.$img.'arr10.png">',
            'label'   => '【翠色猫石】',
            'class'   => 'compact',
            'id'      => 'shubiao6',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
			'desc'    => '<br><img src="'.$img.'arr11.png"><img src="'.$img.'arr12.png">
			<div style="color:#ff4021;"><i class="fa fa-fw fa-info-circle fa-fw"></i>上面七者不可以多选启用，否则会触发代码优先级，可能会报错。</div>',
            'label'   => '【黑白无常】',
            'class'   => 'compact',
            'id'      => 'shubiao7',
            'default' => false,
            'type'    => 'switcher'
        ),
	),));

	//鼠标特效
	CSF::createSection($prefix, array(
    'parent'      => 'global',
	'title'       => '鼠标特效',
	'icon'        => 'fa fa-hand-pointer-o',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '点击彩色粒子掉落',
			'label'   => '点击鼠标会出现彩色粒子掉落',
			'id'      => 'caiselizidiaoluo',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
			'title'   => '鼠标点击随机文字',
			'label'   => '启用后当点击屏幕会以设定的文字随机一条展现出来',
			'id'      => 'random',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('random', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '随机文字(词用""包起来词与词之间用,分离)',
				'id'         => 'random_text',
				'class'      => 'compact',
				'default'    => '"🍉富强🍉","🎉虎虎生威🎉","🍉民主🍉","🍉文明🍉","🧧恭喜发财🧧","🎉金虎送福🎉","🍉和谐🍉","🍉自由🍉","🍉平等🍉","🎉龙腾虎跃🎉","关注关注🙈","🍉公正🍉","🍉法治🍉","🍉欢迎光临🍉","🍉爱国🍉","🍉诚信🍉","🍉友善🍉"',
				'type'       => 'textarea',
			),
		array(
			'title'   => '鼠标点击屏幕炸金花效果',
			'label'   => '点击鼠标会出现五彩斑斓的爆炸特效',
			'id'      => 'zflower',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
			'title'   => '鼠标右键菜单样式美化',
			'label'   => '开启后鼠标右击网站空白处就会发现右键菜单样式和按钮都会改变，喜欢花里胡哨的可以开启',
			'id'      => 'mousebeautify',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
            'title'   => '点击搞笑文字特效',
            'label'   => '点击鼠标会出现文字显示特效',
            'id'      => 'gaoxiao',
            'type'    => 'switcher',
			'default' => false,
        ),
		array(
            'title'   => '鼠标跟随光圈',
            'label'   => '【蓝色】',
            'id'      => 'mouse_cursor',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
            'label'   => '【绿色】',
            'class'   => 'compact',
            'id'      => 'mouse_cursor2',
            'default' => false,
            'type'    => 'switcher'
        ),
        array(
            'title'   => ' ',
            'label'   => '【粉色】',
            'desc'    => '<div style="color:#ff4021;"><i class="fa fa-fw fa-info-circle fa-fw"></i>启用后，将会有一个鼠标光圈实时跟随鼠标移动，上面三者不可以多选启用，否则会触发代码优先级，可能会报错。</div>',
            'class'   => 'compact',
            'id'      => 'mouse_cursor3',
            'default' => false,
            'type'    => 'switcher'
        ),
    ),));

	//动态背景
	CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '动态背景',
	'icon'        => 'fa fa-life-ring',
	'description' => '',
    'default'     => true,
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => ' ',
			'label'   => '【五彩斑斓】',
			'id'      => 'dongtai1',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => ' ',
			'label'   => '【符号元素】',
			'id'      => 'dongtai2',
			'default' => false,
			'type'    => 'switcher',
		), 
		array(
			'title'   => ' ',
			'label'   => '【粒子连线】',
			'id'      => 'Snowfall2lz',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => ' ',
			'label'   => '【四方科技】',
			'id'      => 'specially',
			'default' => false,
			'type'    => 'switcher',
		),
    ),));

	//手机背景
	CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '手机背景',
	'icon'        => 'fa fa-android',
	'description' => '',
    'default'     => true,
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '【淡蓝遐想】',
			'desc'    => '<br><img src="'.$img.'mp.jpg" height="178px">',
			'label'   => '一个不错的日间手机背景',
			'id'      => 'backgroundtu1',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【熏衣彩云】',
			'desc'    => '<br><img src="'.$img.'ce.jpg" height="178px">',
			'label'   => '一个不错的日间手机背景',
			'id'      => 'backgroundtu2',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【遨游题海】',
			'desc'    => '<br><img src="'.$img.'mp1.png" height="178px">',
			'label'   => '一个不错的日间手机背景',
			'id'      => 'backgroundtu3',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【末日审判】',
			'desc'    => '<br><img src="'.$img.'pcd.png" height="178px">',
			'label'   => '一个不错的夜间手机背景',
			'id'      => 'backgroundtu4',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '自定义手机端网站背景图片',
			'label'   => '开启后网站背景将会显示你设置好的背景图片',
			'id'      => 'back',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('back', '!=', ''),
				'title'      => ' ',
			    'subtitle'   => '手机端日间背景图片',
				'id'         => 'back_img_1',
				'class'      => 'compact',
				'default'    => $img . 'admin-beijing.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
			array(
				'dependency' => array('back', '!=', ''),
				'title'      => ' ',
			    'subtitle'   => '手机端夜间背景图片',
				'id'         => 'back_img_2',
				'class'      => 'compact',
				'default'    => $img . 'admin-beijing.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
    ),));

	//侧边背景
	CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '侧边背景',
	'icon'        => 'fa fa-picture-o',
	'description' => '',
    'default'     => true,
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '【淡蓝遐想】',
			'desc'    => '<br><img src="'.$img.'mp.jpg" height="178px">',
			'label'   => '一个不错的侧边栏背景',
			'id'      => 'shoujicebianlan1',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【熏衣彩云】',
			'desc'    => '<br><img src="'.$img.'ce.jpg" height="178px">',
			'label'   => '一个不错的侧边栏背景',
			'id'      => 'shoujicebianlan2',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【遨游题海】',
			'desc'    => '<br><img src="'.$img.'mp1.png" height="178px">',
			'label'   => '一个不错的侧边栏背景',
			'id'      => 'shoujicebianlan3',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '自定义侧边背景',
			'label'   => '开启后会给移动端的网站侧边菜单加上背景图片，用于美化网站！！',
			'id'      => 'backside',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('backside', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '侧边背景图',
				'id'         => 'backside_img',
				'class'      => 'compact',
				'default'    => $img . 'cblbjt.jpg',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
	),));

	//网站背景
    CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '网站背景',
	'icon'        => 'fa fa-television',
	'description' => '',
	'default'     => true,
	'fields'      => array(
		array(
		'type'    => 'submessage',
		'style'   => 'warning',
		'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '【炫彩夜空】',
			'desc'    => '<br><img src="'.$img.'pc.jpg" height="178px">',
			'label'   => '一个不错的日间电脑端背景',
			'id'      => 'pcbackgroundtu1',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【淡蓝遐想】',
			'desc'    => '<br><img src="'.$img.'pc2.jpg" height="178px">',
			'label'   => '一个不错的日间电脑端背景',
			'id'      => 'pcbackgroundtu2',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【遨游题海】',
			'desc'    => '<br><img src="'.$img.'pc1.png" height="178px">',
			'label'   => '一个不错的日间电脑端背景',
			'id'      => 'pcbackgroundtu3',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '【末日审判】',
			'desc'    => '<br><img src="'.$img.'pcd.png" height="178px">',
			'label'   => '一个不错的夜间电脑端背景',
			'id'      => 'pcbackgroundtu4',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '自定义PC端网站背景图片',
			'label'   => '开启后网站背景将会显示你设置好的背景图片',
			'id'      => 'pcback',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('pcback', '!=', ''),
				'title'      => ' ',
				'subtitle'   => 'pc端日间背景图片',
				'id'         => 'pcback_img_1',
				'class'      => 'compact',
				'default'    => $img . 'admin-beijing.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
			array(
				'dependency' => array('pcback', '!=', ''),
				'title'      => ' ',
				'subtitle'   => 'pc端夜间背景图片',
				'id'         => 'pcback_img_2',
				'class'      => 'compact',
				'default'    => $img . 'admin-beijing.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'title'   => '会员开通弹窗背景图片{仿bilibili）',
			'label'   => '开启后会给会员开通弹窗加上背景图片',
			'id'      => 'huiyuanktbj',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('huiyuanktbj', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '左背景图',
				'id'         => 'huiyuanktbj_img',
				'class'      => 'compact',
				'default'    => $img . '22_open.4ea5f239.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
			array(
				'dependency' => array('huiyuanktbj', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '右背景图',
				'id'         => 'huiyuanktbj_img2',
				'class'      => 'compact',
				'default'    => $img . '33_open.f7d7f655.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
	),));

	//飘落特效
    CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '飘落特效',
	'icon'        => 'fa fa-snowflake-o',
	'description' => '',
	'fields'      => array(
		array(
		'type'    => 'submessage',
		'style'   => 'warning',
		'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '浪漫樱花特效',
			'label'   => '启用后，网站全局显示浪漫的樱花飘落特效',
			'id'      => 'yinghua',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '枫叶飘落特效',
			'label'   => '启用后，网站全局显示枫叶飘落特效',
			'desc'    => '<div style="color:#ff4021;"><i class="fa fa-fw fa-info-circle fa-fw"></i>注意：枫叶飘落特效不能和樱花飘落特效一起用喔~</div>',
			'id'      => 'fengye',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '雪花飘落特效',
			'label'   => '启用后，网站全局将会显示雪花飘落的特效',
			'id'      => 'xuehua',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '全局灰色主题',
			'label'   => '启用后，网站全局变灰,适合国家公祭日等纪念日使用',
			'id'      => 'grey',
			'default' => false,
			'type'    => 'switcher'
		),
		array(
			'title'   => '首页灰色主题',
			'label'   => '启用后，网站首页变灰,适合国家公祭日等纪念日使用',
			'id'      => 'grey_page',
			'default' => false,
			'type'    => 'switcher',
		),
    ),));

	//圣诞美化
    CSF::createSection($prefix, array(
	'parent'      => 'global',
	'title'       => '圣诞美化',
	'icon'        => 'fa fa-snowflake-o',
	'description' => '',
	'fields'      => array(
		array(
		'type'    => 'submessage',
		'style'   => 'warning',
		'content' => '<h3 style="color:#fd4c73;"><i class="fa fa-heart fa-fw"></i> 这里是为即将到来的圣诞节准备的</h3>
                <p><b>未避免功能冲突，请先关闭其他相似功能</b><p>',
		),
		array(
			'title'   => '暴风雪',
			'label'   => '这个特效的雪花会跟随鼠标的方向进行飘动',
			'desc'    => 'tips：性能怪兽，电脑性能不好不要开！！！',
			'id'      => 'baofengxue',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '3D逼真雪花',
			'label'   => '开启后，会出现逼真的雪花效果，附带鼠标随动效果',
			'id'      => 'snow3d',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => 'emoji掉落效果',
			'label'   => '开启后掉落圣诞相关emoji',
			'id'      => 'sdemoji',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '下雪特效',
			'label'   => '圆形絮状',
			'id'      => 'xiaxueyx',
			'default' => false,
			'type'    => 'switcher',
		),
			array(
				'dependency' => array('xiaxueyx', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '数量',
				'desc'       => '设置数量，默认200 tips:雨滴效果1000以上',
				'id'         => 'xxshuliang',
				'default'    => '200',
				'type'       => 'text',
			),
			array(
				'dependency' => array('xiaxueyx', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '形状',
				'desc'       => '设置形状，默认10 tips:雨滴效果设置为1-3',
				'id'         => 'xxxingzhuang',
				'default'    => '10',
				'type'       => 'text',
			),
			array(
				'dependency' => array('xiaxueyx', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '飘落速度',
				'desc'       => '设置飘落速度，默认1 tips:雨滴效果设置6以上',
				'id'         => 'xxsudu',
				'default'    => '1',
				'type'       => 'text',
			),
		array(
			'title'   => '导航栏彩灯',
			'label'   => '开启后导航栏会有一排五颜六色的彩灯',
			'id'      => 'sdd',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '圣诞帽',
			'label'   => '给所有用户增加圣诞帽',
			'id'      => 'sdm',
			'default' => false,
			'type'    => 'switcher',
		),
	),));

	//网站字体
	CSF::createSection($prefix, array(
        'parent'      => 'global',
        'title'       => '网站字体',
        'icon'        => 'fa fa-pencil',
        'description' => '',
        'default'     => true,
        'fields'      => array(
            array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'id'      => 'font_size',
			'type'    => 'switcher',
			'label'   => '自定义全局字体',
			'default' => false,
			'title'   => '网站字体样式设置',
		),
			array(
				'dependency' => array('font_size', '!=', ''),
				'title'      => ' ',
				'desc'       => '<div style="color:#ff4021;"><i class="fa fa-fw fa-info-circle fa-fw"></i>字体链接设置(需注意跨域)，默认为AlimamaFangYuanTiVF-Thin.woff2</div>',
				'id'         => 'font_size_url',
				'class'      => 'compact',
				'default'    => '/wp-content/plugins/FACG/zti/AlimamaFangYuanTiVF-Thin.woff2',
				'type'       => 'text',
			),
    ),));

	//全局美化
	CSF::createSection($prefix, array(
        'parent'      => 'global',
        'title'       => '全局美化',
        'icon'        => 'fa fa-bullseye',
        'description' => '',
        'default'     => true,
        'fields'      => array(
            array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'id'      => 'fengsemaoer',
			'type'    => 'switcher',
			'label'   => '开启后你就知道了',
			'default' => false,
			'title'   => '粉色猫耳朵',
		),
			array(
				'dependency' => array('fengsemaoer', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片',
				'id'         => 'fengsemaoer_img',
				'class'      => 'compact',
				'default'    => $img . 'bg-cat-main-code.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'id'      => 'shuzifanye',
			'type'    => 'switcher',
			'label'   => '开启后翻页按钮会出现渐变颜色（需在主题设置>文章列表 将列表翻页模式设置为数字翻页按钮）',
			'default' => false,
			'title'   => '数字翻页按钮美化',
		),
		array(
			'id'      => 'jiazaigd',
			'type'    => 'switcher',
			'label'   => '加载更多美化（需在主题设置>文章列表 将列表翻页模式设置为AJAX追加列表翻页）',
			'default' => false,
			'title'   => '加载更多按钮美化',
		),
			array(
				'dependency' => array('jiazaigd', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片',
				'id'         => 'jiazaigd_img',
				'class'      => 'compact',
				'default'    => $img . 'jiazaigd.png',
				'preview'    => true,
				'library'    => 'image', 'type' => 'upload',
			),
			array(
				'dependency' => array('jiazaigd', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '虚线显示颜色',
				'id'         => 'jiazaigdxuxian_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
			array(
				'dependency' => array('jiazaigd', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '鼠标移入实线显示颜色',
				'id'         => 'jiazaigdshixian_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
			array(
				'dependency' => array('jiazaigd', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '鼠标移入字体颜色',
				'id'         => 'jiazaigdzth_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'title'   => __('边框细节优化'),
			'id'      => 'biankuangxj',
			'type'    => 'switcher',
			'default' => false,
			'label'   => '启用后有边框，非常的哇塞！',
		),
			array(
				'dependency' => array('biankuangxj', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '边框显示颜色',
				'id'         => 'biankuangxj_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'title'   => '图标美化',
			'label'   => '美化子比内置的86个svg图标',
			'id'      => 'icon_js',
			'default' => false,
			'type'    => 'switcher',
		    ),
		array(
			'title'   => '原神启动！',
			'label'   => '开屏动画变成原神启动时的样子',
			'desc'    => '通用美化',
			'id'      => 'yuanshen',
			'default' => false,
			'type'    => 'switcher',
		    ),
			array(
				'dependency' => array('yuanshen', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片',
				'id'         => 'yuanshen_img',
				'class'      => 'compact',
				'default'    => $img . '1154045358.svg',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
    ),));
	
//导航&美化
    CSF::createSection($prefix, array(
        'id'    => 'Navigation',
        'title' => '导航&美化',
        'icon'  => 'fa fa-list'
    ));	
	
	//logo滤镜
	CSF::createSection($prefix, array(
	'parent'      => 'Navigation',
	'title'       => 'logo滤镜',
    'icon'        => 'fa fa-spinner',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'title'   => '网站LOGO扫光',
			'label'   => '开启后网站LOGO会有扫光的效果（日间夜间都已经适用）',
			'id'      => 'logoflash',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => 'LOGO色彩渐变',
			'label'   => '网站LOGO将会进行动态色彩渐变',
			'id'      => 'logogradient',
			'default' => false,
			'type'    => 'switcher',
		),
        array(
            'title'   => 'LOGO反色',
            'label'   => '网站LOGO的色彩将进行反色处理，可以看效果喔~',
            'id'      => 'logo2',
            'default' => false,
            'type'    => 'switcher'
        ) ,
        array(
            'title'   => 'LOGO夜间反色',
            'label'   => '网站LOGO夜间反色',
            'id'      => 'logo3',
            'default' => false,
            'type'    => 'switcher'
        ) ,
        array(
            'title'   => 'LOGO淡绿色阴影',
            'label'   => '网站LOGO将会被添加一个淡绿色柔光背景',
            'id'      => 'logo4',
            'default' => false,
            'type'    => 'switcher'
        ,)	
	),));
	
	//导航栏内容
	CSF::createSection($prefix, array(
        'parent'      => 'Navigation',
        'title'       => '导航栏内容',
        'icon'        => 'fa fa-bar-chart',
        'description' => '',
        'default'     => true,
        'fields'      => array(
            array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
        array(
			'title'   => '导航栏字体加粗',
			'label'   => '导航栏上面的字体加粗，比子比原本的看着更漂亮',
			'id'      => 'navigation',
			'default' => false,
			'type'    => 'switcher',
		),
			array(
				'dependency' => array('navigation', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '导航栏字体大小',
				'id'         => 'navigation_num',
				'class'      => 'compact',
				'default'    => 700,
				'min'        => 500,
				'max'        => 1000,
				'step'       => 50,
				'unit'       => 'px',
				'type'       => 'spinner',
			),
		array(
			'title'   => '标题样式美化',
			'label'   => '导航栏标题将简化主题自带的标题hover效果',
			'id'      => 'navbiaoti',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '禁用搜索功能',
			'label'   => '禁用导航栏顶部的搜索功能',
			'id'      => 'nosearch',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => __('FPS帧率显示'),
			'id'      => 'show_fps',
			'type'    => 'switcher',
			'default' => false,
			'label'   => '启用后会在所有页面左上角加个帧率显示可以实时观察网站帧率，非常的哇塞！',
		),
			array(
				'dependency' => array('show_fps', '!=', ''),
				'title'      => ' ',
				'subtitle'   => 'fps帧率上下位置',
				'id'         => 'show_fps_wz',
				'class'      => 'compact',
				'default'    => 30,
				'min'        => 0,
				'max'        => 100,
				'step'       => 1,
				'type'       => 'spinner',
			),
			array(
				'dependency' => array('show_fps', '!=', ''),
				'title'      => ' ',
				'subtitle'   => 'fps帧率大小',
				'id'         => 'show_fps_dx',
				'class'      => 'compact',
				'default'    => 15,
				'min'        => 0,
				'max'        => 20,
				'step'       => 1,
				'unit'       => 'px',
				'type'       => 'spinner',
			),
			array(
				'dependency' => array('show_fps', '!=', ''),
				'title'      => ' ',
				'subtitle'   => 'fps帧率显示颜色',
				'id'         => 'show_fps_color',
				'class'      => 'compact',
				'default'    => '#e44033',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'title'   => '自定义导航栏皮肤',
			'label'   => '开启后可自定义导航栏皮肤（花里胡哨）',
			'id'      => 'usernavbg8',
			'type'    => 'switcher'
        ),
            array(
                'title'      => ' ',
                'desc'       => '请上传自定义导航栏背景图片或填写图片地址，注意尺寸为：1800px*80px',
                'dependency' => array(
                    'usernavbg8',
                    '!=',
                    ''
                ),
                'id'         => 'usernavbg88',
                'class'      => 'compact',
                'default'    => $img . 'dmss.gif',
                'preview'    => true,
                'library'    => 'image',
                'type'       => 'upload'
            ),
		array(
			'title'   => '搜索框背景',
			'label'   => '下拉搜索框添加一个粉色星星背景',
			'id'      => 'ssbj',
			'default' => false,
			'type'    => 'switcher',
		),
			array(
				'dependency' => array('ssbj', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片',
				'id'         => 'ssbj_img',
				'class'      => 'compact',
				'default'    => $img . 'shading_red.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
		'title'   => '右上角开通会员炫彩色',
		'label'   => '开启后修改右上角会员开通背景色',
		'id'      => 'hyktxc',
		'default' => false,
		'type'    => 'switcher',
		),
    ),));
	
//局部&美化
	CSF::createSection($prefix, array(
        'id'    => 'local',
        'title' => '局部&美化',
        'icon'  => 'fa fa-clone'
    ));
	
	//用户头像
	CSF::createSection($prefix, array(
        'parent'      => 'local',
        'title'       => '用户头像',
        'icon'        => 'fa fa-user-circle',
        'description' => '',
        'default'     => true,
        'fields'      => array(
            array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
            array(
                'title'   => '用户头像美化',
                'label'   => '头像彩色呼吸光环+悬停放大',
                'id'      => 'facg_avatar',
                'default' => false,
                'type'    => 'switcher'
            ),
            array(
                'title'   => '彩色昵称',
                'label'   => '开启后用户的昵称会变成彩色的',
                'id'      => 'csnc',
                'default' => false,
                'type'    => 'switcher'
            ),
			array(
                'title'   => '昵称抖动',
                'label'   => '抖音都看过吧，开启后让你的昵称像抖音一样炫彩抖动',
                'id'      => 'dydd',
                'default' => false,
                'type'    => 'switcher'
            ),
            array(
                'title'   => '头像摇摆',
                'label'   => '开启后刷新页面小工具用户的头像会左右摇摆',
                'id'      => 'facg_avatar_yb',
                'default' => false,
                'type'    => 'switcher'
            ),
    ),));
	
	//左侧美化
	CSF::createSection($prefix, array(
	'parent'      => 'local',
	'title'       => '左侧美化',
    'icon'        => 'fa fa-arrow-circle-left',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	    array(
			'title'      => '左侧显示联系站长按钮',
			'label'      => '启用后会在网站的左侧显示联系站长按钮',
			'id'         => 'qq',
			'type'       => 'switcher',
			'default'    => false,
		),
			array(
				'dependency' => array('qq', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '联系站长按钮文字',
				'id'         => 'qq_text',
				'class'      => 'compact',
				'default'    => '联系站长',
				'type'       => 'text',
			),
			array(
				'dependency' => array('qq', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '联系站长按钮链接',
				'label'      => '请填写联系站长的url链接',
				'id'         => 'qq_url',
				'class'      => 'compact',
				'default'    => 'http://wpa.qq.com/msgrd?v=3&uin=1111111111&site=qq&menu=yes',
				'type'       => 'text',
			),
    ),));	
	//右侧美化
	CSF::createSection($prefix, array(
	'parent'      => 'local',
	'title'       => '右侧美化',
    'icon'        => 'fa fa-arrow-circle-right',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	    array(
			'title'   => '右侧悬浮按钮图片',
			'label'   => '右侧悬浮按钮美化——欢迎光临',
			'id'      => 'suspension',
			'default' => false,
			'type'    => 'switcher',
		),
			array(
				'dependency' => array('suspension', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片',
				'id'         => 'suspension_img',
				'class'      => 'compact',
				'default'    => $img . 'aa1.gif',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'id'      => 'scroll',
			'type'    => 'switcher',
			'label'   => '单色滚动条',
			'desc'    => '网站滚动条为单色，可以通过下面设置颜色',
			'default' => false,
			'title'   => __('网站侧边滚动条样式'),
		),
			array(
				'dependency' => array('scroll', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '单色滚动条显示颜色',
				'id'         => 'scroll_color',
				'default'    => '#dd3333',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'id'      => 'scrollbar',
			'class'   => 'compact',
			'type'    => 'switcher',
			'label'   => '渐变色滚动条',
			'desc'    => '网站滚动条为渐变色，可以通过下面设置颜色',
			'default' => false,
			'title'   => ' ',
		),
			array(
				'dependency' => array('scrollbar', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '渐变色滚动条显示颜色',
				'id'         => 'scrollbar_color',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#1f9ae6',
			),
			array(
				'dependency' => array('scrollbar', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '渐变色滚动条显示颜色二',
				'id'         => 'scrollbar_color_1',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#00cfd8',
			),
			array(
				'dependency' => array('scrollbar', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '渐变色滚动条显示颜色三',
				'id'         => 'scrollbar_color_2',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#e4e4e4',
			),
		array(
			'id'      => 'scroll_bar',
			'type'    => 'switcher',
			'class'   => 'compact',
			'label'   => '彩色滚动条(更优雅)',
			'desc'    => '网站滚动条为彩色，只有默认不可以自行设置颜色',
			'default' => false,
			'title'   => ' ',
		),
			array(
				'dependency' => array('scroll_bar', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '彩色滚动条宽度',
				'id'         => 'scroll_bar_px',
				'class'      => 'compact',
				'desc'       => __('滚动条最大值可以设置为10px'),
				'default'    => 5,
				'max'        => 10,
				'min'        => 0,
				'step'       => 1,
				'unit'       => 'PX',
				'type'       => 'spinner',
			),
		array(
			'title'   => '可爱调皮小猫',
			'label'   => '开启后侧边会出现可爱的调皮小猫，具体效果可以自行开启后体验',
			'id'      => 'cat',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
			'title'   => '悬浮按钮美化',
			'label'   => '开启后侧边悬浮按钮会变成美色渐变',
			'id'      => 'xfan',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
			'title'   => '悬浮按钮美化-新',
			'label'   => '开启后侧边悬浮按钮会变成美色渐变',
			'id'      => 'xfanx',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('xfanx', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '按钮上方小图自定义',
				'id'         => 'suspension_imgss',
				'class'      => 'compact',
				'default'    => '',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),	
	),));
	
	//底部美化
	CSF::createSection($prefix, array(
        'parent'      => 'local',
        'title'       => '底部美化',
        'icon'        => 'fa fa-arrow-circle-down',
        'description' => '',
        'default'     => true,
        'fields'      => array(
            array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'title'   => '底部二维码滤镜一',
			'label'   => 'hue-rotate 色相旋转',
			'id'      => 'erweima1',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '底部二维码滤镜二',
			'label'   => 'invert 反色',
			'id'      => 'erweima2',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '底部二维码滤镜三',
			'label'   => 'drop-shadow 阴影',
			'id'      => 'erweima3',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '底部收藏本站',
			'label'   => '开启后将在网站底部显示Ctrl+D收藏本站提示',
			'id'      => 'dixian',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
			'title'   => '底部添加蓝色波浪',
			'label'   => '启用后会在所有页面底部<code>footer</code>下面添加底部蓝色波浪，非常的哇塞！',
			'id'      => 'wave',
			'type'    => 'switcher',
			'default' => false,
			),
		array(
			'title'   => '右下角蒲公英',
			'label'   => '开启后网站底部将显示动态蒲公英特效',
			'id'      => 'plbj5',
			'default' => false,
			'type'    => 'switcher'
		) ,
		array(
            'title'   => '网站运行时间',
            'label'   => '开启后可在网站底部显示彩色运行时间',
            'id'      => 'timeauthor',
            'default' => false,
            'type'    => 'switcher'
        ) ,
			array(
				'title'      => ' ',
				'desc'       => '请填写您的建站时间，如：2023-08-01',
				'id'         => 'timeauthor1',
				'default'    => false,
				'type'       => 'text',
				'dependency' => array(
					'timeauthor',
					'!=',
					''
				) ,
				'class'      => 'compact'
			) ,
		array(
			'title'   => '会员引导悬浮窗',
			'label'   => '开启后将在网站底部显示活动倒计时提示',
			'id'      => 'hddjs',
			'default' => false,
			'type'    => 'switcher'
		) ,
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动背景图片设置',
				'id'         => 'hddjs_img',
				'default'    => $img . 'hdbjt.png',
				'preview'    => true,
				'class'      => 'compact',
				'library'    => 'image',
				'type'       => 'upload',
				),
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动标题',
				'id'         => 'hddjs_text_1',
				'class'      => 'compact',
				'default'    => '限时钜惠',
				'type'       => 'text',
			),
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动副标题（日期等）',
				'id'         => 'hddjs_text_2',
				'class'      => 'compact',
				'default'    => '2024年1月1日至12月28日',
				'type'       => 'text',
			),
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动结束时间（注意格式）',
				'id'         => 'hddjs_text_3',
				'class'      => 'compact',
				'default'    => '2024/12/28,9:00:00',
				'type'       => 'text',
			),
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动按钮标题',
				'id'         => 'hddjs_text_4',
				'class'      => 'compact',
				'default'    => '永久会员仅需68￥',
				'type'       => 'text',
			),
			array(
				'dependency' => array('hddjs', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '活动按钮链接（会员开通无需修改）',
				'id'         => 'hddjs_text_5',
				'class'      => 'compact',
				'default'    => 'javascript:void(0);',
				'type'       => 'text',
			),
	),));
	
	//顶部美化
	CSF::createSection($prefix, array(
        'parent'      => 'local',
        'title'       => '顶部美化',
        'icon'        => 'fa fa-arrow-circle-up',
        'description' => '',
        'default'     => true,
        'fields'      => array(
             array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	    array(
			'title'   => '新年网站对联',
			'label'   => '启用后会在网站的两侧添加对联，对联的图片也可以自己修改，新年的时候可以启用冲冲节气(建议屏幕大小设置为1200px)',
			'id'      => 'duilian',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('duilian', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '左侧对联图片设置',
				'id'         => 'duilian_img_1',
				'default'    => $img . 'duilian-zuo.png',
				'preview'    => true,
				'class'      => 'compact',
				'library'    => 'image', 'type' => 'upload',
			),
			array(
				'dependency' => array('duilian', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '右侧对联图片设置',
				'id'         => 'duilian_img_2',
				'default'    => $img . 'duilian-you.png',
				'preview'    => true,
				'class'      => 'compact',
				'library'    => 'image', 'type' => 'upload',
			),
		array(
			'title'   => '网站动态标题',
			'label'   => '启用后如果切换到另一个页面会显示《你别走吖 Σ(っ °Д °;)っ》如果切换回来则显示《(/≧▽≦/)你又回来啦！》',
			'id'      => 'title',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('title', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '动态标题进入窗口文字',
				'id'         => 'title_text_1',
				'class'      => 'compact',
				'default'    => '(/≧▽≦/)你又回来啦！',
				'type'       => 'text',
			),
			array(
				'dependency' => array('title', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '动态标题切换窗口文字',
				'id'         => 'title_text_2',
				'class'      => 'compact',
				'default'    => '你别走吖 Σ(っ °Д °;)っ',
				'type'       => 'text',
			),
		array(
			'title'   => '顶部彩色进度条',
			'label'   => '启用后，网站顶部将显示一个彩色的进度条',
			'id'      => 'jindutiao',
			'default' => false,
			'type'    => 'switcher'
        ) ,
        array(
			'title'   => '元旦灯笼',
			'label'   => '启用后，网站右上角将呈现元旦灯笼特效',
			'id'      => 'chunjie',
			'default' => false,
			'type'    => 'switcher'
        ) ,
		array(
			'title'   => '年兽',
			'label'   => '启用后，网站右上角将呈现悬挂年兽',
			'id'      => 'nianshou',
			'default' => false,
			'type'    => 'switcher'
        ) ,
			array(
				'dependency' => array('nianshou', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '图片设置',
				'id'         => 'nianshou_img',
				'default'    => $img . 'nianshou.png',
				'preview'    => true,
				'class'      => 'compact',
				'library'    => 'image', 'type' => 'upload',
			),
        array(
			'title'   => '幻灯片指示器优化',
			'label'   => '启用后，幻灯片指示器将会圆角显示',
			'id'      => 'swiper',
			'default' => false,
			'type'    => 'switcher'
        ) ,
	),));
	
//文章&美化
	CSF::createSection($prefix, array(
        'id'    => 'article',
        'title' => '文章&美化',
        'icon'  => 'fa fa-fw fa-map-o'
    ));
	
	//文章功能
	CSF::createSection($prefix, array(
	'parent'      => 'article',
	'title'       => '文章功能',
    'icon'        => 'fa fa-file-text',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
            'id'    => 'posts_gqts',
            'type'  => 'switcher',
            'title' => '文章底部添加过期提示',
        ),
		array(
            'dependency' => array('posts_gqts', '!=', ''),
            'id'         => 'posts_gqts_sz',
            'type'       => 'fieldset',
            'title'      => '文章底部添加过期提示参数设置',
            'fields'     => array(
                array(
                    'id'         => 'text',
                    'type'       => 'textarea',
                    'title'      => '过期提示内容',
                    'default'    => '某些文章具有时效性，若有错误或已失效，请在下方<a href="#comment">留言</a>或联系<a target="_blank" title="'. get_bloginfo('name') .'" href="'. get_bloginfo('url') .'"><b>'. get_bloginfo('name') .'</b></a>。
                    ',
                ),
            ),
        ),
	),));

	//页面美化
	CSF::createSection($prefix, array(
	'parent'      => 'article',
	'title'       => '页面美化',
    'icon'        => 'fa fa-newspaper-o',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	    array(
            'title'   => '文章阴影边缘',
            'label'   => '启用后，文章页将会添加一个自定义颜色柔光边缘',
            'id'      => 'article_box_shadow',
            'default' => false,
            'type'    => 'switcher'
            ) ,
			array(
				'dependency' => array('article_box_shadow', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '自定义未点击前颜色',
				'id'         => 'article_box_shadow_ys1',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#2ea7e0',
			),
			array(
				'dependency' => array('article_box_shadow', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '自定义点击后颜色',
				'id'         => 'article_box_shadow_ys2',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#2ea7e0',
			),
	    array(
			'title'   => '文章标题鼠标悬停划线',
			'label'   => '开启后，鼠标指针指在文章标题上会进行动态划线，移开又取消划线。',
			'id'      => 'xthx',
			'type'    => 'switcher',
			'default' => false,
		),
		array(
			'title'   => '文章内页彩色标签',
			'label'   => '开启后文章的内页标签将以彩色的效果展示出来，每个标签颜色都不同',
			'id'      => 'after',
			'default' => false,
			'type'    => 'switcher',
		),
		array(
			'title'   => '小标题美化',
			'label'   => '开启后写文章用的小标题将以美化后的效果展现出来，非常的好看哇塞',
			'id'      => 'subtitle',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('subtitle', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '小标题h2图片',
				'id'         => 'subtitle_h2',
				'class'      => 'compact',
				'default'    => $img . 'h2.svg',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
			array(
				'dependency' => array('subtitle', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '小标题h3图片',
				'id'         => 'subtitle_h3',
				'class'      => 'compact',
				'default'    => $img . 'h3.svg',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
	),));
	
	//评论美化
	CSF::createSection($prefix, array(
	'parent'      => 'article',
	'title'       => '评论美化',
    'icon'        => 'fa fa-fw fa-comments',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'title'   => '评论框背景图添加快来说点啥',
			'label'   => '开启后评论会出现一张[快来说点啥]样式的背景图，用于美化子比简单又低调的评论框',
			'id'      => 'comment_back',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('comment_back', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '评论框背景图设置',
				'id'         => 'comment_back_img',
				'class'      => 'compact',
				'default'    => $img . 'pinglun.svg',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'title'   => '评论区背景图',
			'label'   => '评论区红、蓝背景轮询切换',
			'id'      => 'facg_comment_back',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('facg_comment_back', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '评论区背景图设置',
				'id'         => 'facg_comment_back_img',
				'class'      => 'compact',
				'default'    => $img . 'shading_blue.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
			array(
				'dependency' => array('facg_comment_back', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '评论区背景图2设置',
				'id'         => 'facg_comment_back_img2',
				'class'      => 'compact',
				'default'    => $img . 'shading_red.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'title'   => '首页评论美化',
			'label'   => '首页评论会以圆角虚线形式输出',
			'id'      => 'index_comments',
			'default' => false,
			'type'    => 'switcher',
		),
        array(
			'title'   => '评论区UID',
			'label'   => '评论区显示用户的ID',
			'id'      => 'comment_uid',
			'default' => false,
			'type'    => 'switcher',
            ),
            array(
                'title'      => ' ',
                'desc'       => '预留位，例如你网站有100用户预留5位则第一百位用户ID显示为<code style="color:red;">00100</code>',
                'id'         => 'comment_uid_s',
                'default'    => 5,
                'unit'       => '位',
                'max'        => 30,
                'min'        => 3,
                'step'       => 1,
                'type'       => 'spinner',
                'dependency' => array('comment_uid', '!=', ''),
                'class'      =>'compact',
            ),
		array(
			'title'   => '评论区背景图(蓝色款)',
			'id'      => 'facg_comment_blue',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('facg_comment_blue', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '评论区背景图设置',
				'id'         => 'facg_comment_blue_img',
				'class'      => 'compact',
				'default'    => $img . 'shading_blue.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
			'title'   => '评论区背景图(红色款)',
			'id'      => 'facg_comment_red',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('facg_comment_red', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '评论区背景图设置',
				'id'         => 'facg_comment_red_img',
				'class'      => 'compact',
				'default'    => $img . 'shading_red.png',
				'preview'    => true,
				'library'    => 'image',
				'type'       => 'upload',
			),
		array(
		'title'   => '评论小工具',
		'label'   => '评论小工具每个评论都加上一个边框',
		'id'      => 'plxgj',
		'default' => false,
		'type'    => 'switcher',
		),
			array(
				'dependency' => array('plxgj', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '边框颜色',
				'id'         => 'plxgj_ys',
				'class'      => 'compact',
				'type'       => "color",
				'default'    => '#2ea7e0',
			),
		array(
		'title'   => '侧边栏评论小工具',
		'label'   => '给侧边栏评论小工具加个背景～',
		'id'      => 'cblplxgj',
		'default' => false,
		'type'    => 'switcher',
		),
	),));
	
	//列表美化
	CSF::createSection($prefix, array(
	'parent'      => 'article',
	'title'       => '列表美化',
    'icon'        => 'fa fa-fw fa-file-text-o',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	    array(
			'id'      => 'articlefloat',
			'type'    => 'switcher',
			'label'   => '上悬浮底部伴有蓝色跳跳',
			'default' => false,
			'title'   => __('首页文章悬浮样式', 'zib_language'),
		),
			array(
				'dependency' => array('articlefloat', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '跳跳颜色',
				'id'         => 'articlefloat_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'id'      => 'postfloat',
			'type'    => 'switcher',
			'class'   => 'compact',
			'label'   => '晃动样式悬浮(更优雅)',
			'default' => false,
			'title'   => ' ',
		),
			array(
				'dependency' => array('postfloat', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '阴影颜色',
				'id'         => 'postfloat_color',
				'default'    => '#2ea7e0',
				'class'      => 'compact',
				'type'       => "color",
			),
		array(
			'id'      => 'wzkpjumps',
			'type'    => 'switcher',
			'class'   => 'compact',
			'label'   => '文章卡片果冻弹跳特效',
			'default' => false,
			'title'   => ' ',
			'desc'    => '<div style="color:#ff4021;"><i class="fa fa-fw fa-info-circle fa-fw"></i>文章悬浮样式(三项)不可同时开启</div>',
		),
		array(
			'title'   => '文章列表悬停萝莉',
			'label'   => '开启后文章列表悬停萝莉',
			'id'      => 'post_ll',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('post_ll', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '悬停图片',
				'id'         => 'post_ll_img',
				'class'      => 'compact',
				'default'    => $img . 'decorate1.png',
				'preview'    => true,
				'library'    => 'image', 'type' => 'upload',
			),
			array(
				'dependency' => array('post_ll', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '滑动时间',
				'id'         => 'post_ll_s',
				'class'      => 'compact',
				'default'    => 0.5,
				'min'        => 0,
				'max'        => 10,
				'step'       => 0.1,
				'unit'       => '秒',
				'type'       => 'spinner',
			),
		array(
            'title'   => '文章卡片模式排列',
            'label'   => '当首页默认模式不为卡片模式时，此开关无效(仅对pc端有效)',
            'id'      => 'wzcard',
            'default' => false,
            'type'    => 'switcher',
        ),
			array(
				'dependency' => array('wzcard', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '每行显示个数',
				'id'         => 'wzcard_num',
				'class'      => 'compact',
				'default'    => 4,
				'min'        => 3,
				'max'        => 5,
				'step'       => 1,
				'unit'       => '个',
				'type'       => 'spinner',
			),
		array(
            'title'   => '文章置顶+新文章发布ICON图标',
            'label'   => '开启后文章缩略图右上角会显示ICON图标，关闭后可以一键去除。',
            'id'      => 'postICON',
            'type'    => 'switcher',
            'default' => false,
        ),
			array(
				'dependency' => array('postICON', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '文章置顶ICON图标',
				'id'         => 'post_img',
				'class'      => 'compact',
				'default'    => $img . 'wzzhiding.png',
				'library'    => 'image', 'type' => 'upload',
			),
			array(
				'dependency' => array('postICON', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '新文章发布ICON图标',
				'id'         => 'new_post_img',
				'class'      => 'compact',
				'default'    => $img . 'xinwz.png',
				'library'    => 'image', 'type' => 'upload',
			),
		array(
			'title'   => '文章卡片标题',
			'label'   => '开启后美化文章卡片标题',
			'id'      => 'kapianbt',
			'type'    => 'switcher',
			'default' => false,
		),
			array(
				'dependency' => array('kapianbt', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '标题颜色',
				'id'         => 'kapianbt_color',
				'default'    => '#612a8c',
				'class'      => 'compact',
				'type'       => "color",
			),
			array(
				'dependency' => array('kapianbt', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '文章卡片标题左图标设置',
				'id'         => 'kapianbt_img',
				'class'      => 'compact',
				'default'    => $img . 'ico_deko.svg',
				'preview'    => true,
				'library'    => 'image', 'type' => 'upload',
			),
			array(
				'dependency' => array('kapianbt', '!=', ''),
				'title'      => ' ',
				'subtitle'   => '文章卡片标题右图标设置',
				'id'         => 'kapianbt_img2',
				'class'      => 'compact',
				'default'    => $img . 'ico_boko.svg',
				'preview'    => true,
				'library'    => 'image', 'type' => 'upload',
				'desc'       => '注：建议尺寸width="167px" height="131px"',
			),
	),));

//功能&设置
    CSF::createSection($prefix, array(
        'id'    => 'gongneng',
        'title' => '功能&设置',
        'icon'  => 'fa fa-pie-chart',
    ));
	
//维护模式
	CSF::createSection($prefix, array(
	'parent'      => 'gongneng',
	'title'       => '维护模式',
    'icon'        => 'fa fa-wrench',
	'fields'      => array(
		array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => '维护模式仅用于网站调试阶段使用，开启后只有登陆状态下的管理员账号权限才可以看到网站的正常内容，其他访客将显示维护倒计时。<br/><b style="color:red;font-size:16px;">注意：</b><b style="font-size:16px;">如果不幸被锁在倒计时界面，只需访问: </b>' . '<b style="color:red;font-size:16px;">https://'.$_SERVER['HTTP_HOST'].'/wp-login.php</b><b style="color:blue;font-size:16px;">，登录管理员账户即可。</b>',
	    ),
        array(
            'id'      => 'is_maintenance',
            'type'    => 'switcher',
            'title'   => '开启维护（曦颜版）',
            'label'   => '网站正式上线后一定要记得关闭维护模式',
            'default' => false,
        ),
			array(
				'id'         => 'maintenance_logo',
				'type'       => 'upload',
				'title'      => 'LOGO',
				'desc'       => '自行设置',
				'default'    => $img . 'logo-dark.png',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_title',
				'type'       => 'text',
				'title'      => '标题',
				'desc'       => '维护标题',
				'default'    => '网站维护中',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_desc',
				'type'       => 'textarea',
				'title'      => '描述内容',
				'desc'       => '可使用html格式',
				'attributes' => array(
					'style'  => 'width: 100%;',
				),
				'default'    => '<p><br>抱歉，我们的网站正在维护中...<br><span class="dull-text">敬请关注网站开放时间！</span><br></p>',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_time',
				'type'       => 'text',
				'title'      => '开放时间',
				'desc'       => '预计网站开放时间，格式：2024/06/21 12:00',
				'default'    => '2024/06/21 12:00',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_redirectUrl',
				'type'       => 'text',
				'title'      => '显示备用站点地址',
				'desc'       => '如果你有站点维护中时存在的其他备用站点，请填写链接地址。如https://facg.top',
				'default'    => 'https://facg.top',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_redirectUrlName',
				'type'       => 'text',
				'title'      => '显示备用站点名称',
				'desc'       => '备用站点名称',
				'default'    => '枫次元',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_copyright',
				'type'       => 'text',
				'title'      => '显示网站版权信息',
				'desc'       => '',
				'default'    => 'Copyright © 2024. 枫影.',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
			array(
				'id'         => 'maintenance_beian',
				'type'       => 'text',
				'title'      => '显示网站备案号',
				'desc'       => '填写网站备案号',
				'default'    => '皖ICP备88888888号',
				'dependency' => array('is_maintenance', '==', 'true'),
			),
		array(
			'id'      => 'JUANYI_MTCE_SETTING_OPEN',
			'type'    => 'switcher',
			'title'   => '开启维护（倦意版）',
			'label'   => '是否开启？',
			'default' => '0',
		),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_TIME',
                'type'  => 'text',
                'title' => '截至时间',
                'subtitle' => '格式：年-月-日 时:分:秒',
                'default' => '2024-06-21 12:00:00',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
            
            array(
                'id'    => 'JUANYI_MTCE_SETTING_STATUS',
                'type'  => 'text',
                'title' => '状态码',
                'subtitle' => '不懂不建议更改',
                'default' => '503',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),

            array(
                'id'    => 'JUANYI_MTCE_SETTING_TITLE',
                'type'  => 'text',
                'title' => '标题',
                'default' => '网站正在更新中',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_SUBTITLE',
                'type'  => 'textarea',
                'title' => '副标题',
                'default' => '更新会带来更好的体验，对于给您带来的不便，我们深表歉意。请稍后查看，在维护完成之前您可以先加入我们的交流群。',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_CONTACT_QQQUN',
                'type'  => 'switcher',
                'title' => '联系QQ群',
                'label' => '是否开启？',
                'default' => '0',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_CONTACT_QQQUN_URL',
                'type'  => 'text',
                'title' => 'QQ群地址',
                'default' => 'http://qm.qq.com/',
                'dependency' => array('JUANYI_MTCE_SETTING_CONTACT_QQQUN', '==', '1'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_CONTACT_TG',
                'type'  => 'switcher',
                'title' => '联系TG群',
                'label' => '是否开启？',
                'default' => '0',
				'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_CONTACT_TG_URL',
                'type'  => 'text',
                'title' => 'TG群地址',
                'default' => 'https://t.me/',
                'dependency' => array('JUANYI_MTCE_SETTING_CONTACT_TG', '==', '1'),
            ),
            array(
                'id'    => 'JUANYI_MTCE_SETTING_EXTRA',
                'type'  => 'code_editor',
                'title' => '额外CSS',
                'default' => '/*手机版*/
@media (max-width: 800px) {p {
    margin-left:20px;
    margin-right:20px;
}}',
                'dependency' => array('JUANYI_MTCE_SETTING_OPEN', '==', 'true'),
            ),
    ),));

//静态&资源
    CSF::createSection($prefix, array(
        'id'    => 'FACG_static',
        'title' => '静态&资源',
        'icon'  => 'fa fa-rocket'
    ));
	
    CSF::createSection($prefix, array(
	'parent'      => 'FACG_static',
	'title'       => '静态资源',
    'icon'        => 'fa fa-rocket',
	'fields'      => array(
        array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
		array(
			'title'   => '静态资源',
			'label'   => '设置指定托管地址以后，会将枫影美化插件的CSS、JS的地址统一改为设定的地址',
			'id'      => 'FACGstatic',
			'type'    => 'switcher',
			'default' => true,
		),
		array(
			'dependency' => array('FACGstatic', '!=', ''),
			'title'      => __('托管地址'),
			'desc'       => '请输入枫影美化插件静态资源托管地址，默认为/wp-content/plugins/FACG <a target="_bank" href="https://facg.top">查看教程</a>',
			'id'         => 'static_FACG',
			'class'      => 'compact',
			'default'    => '/wp-content/plugins/FACG',
			'preview'    => true,
			'type'       => 'text',
		),
	),));	

//系统&环境
    CSF::createSection($prefix, array(
	'title'       => '系统&环境',
	'icon'        => 'fa fa-fw fa-file-text',
	'description' => '',
	'fields'      => array(
		array(
		  'type'    => 'submessage',
		  'style'   => 'warning',
		  'content' => ''. $new_badge['TXT'],
		),
		array(
			'title'   => '系统环境',
			'type'    => 'content',
			'content' => '<div style="margin-left:14px;"><li><strong>操作系统</strong>： ' . PHP_OS . ' </li>
			<li><strong>运行环境</strong>： ' . $_SERVER["SERVER_SOFTWARE"] . ' </li>
			<li><strong>PHP版本</strong>： ' . PHP_VERSION . ' </li>
			<li><strong>WordPress版本</strong>： ' . get_bloginfo('version') . '</li>
			<li><strong>系统信息</strong>： ' . php_uname() . ' </li>
			<li><strong>服务器时间</strong>： ' . current_time('mysql') . '</li>
			<li><strong>数据库查询次数</strong>： ' . sprintf(__('查询 %s 次，','b2'),get_num_queries()) . '</li>
			<li><strong>设置项生成耗时</strong>： ' . sprintf(__('耗时 %s 秒','b2'),timer_stop(0,4)) . '</li></div>',
		),
		array(
			'title'   => '推荐环境',
			'type'    => 'content',
			'content' => '<div style="margin-left:14px;"><li><strong>WordPress</strong>：5.0+，推荐使用最新版</li>
			<li><strong>PHP</strong>：PHP推荐使用7.4</li>
			<li><strong>服务器配置</strong>：因为现在WordPress最新版沉重的原因，推荐最低使用2H4G服务器</li>
			<li><strong>操作系统</strong>：无要求，不推荐使用Windows系统</li></div>',
		),
	),));

//导入&导出
	CSF::createSection( $prefix, array(
	'title'       => '导入&导出',
	'icon'        => 'fa fa-fw fa-copy',
	'description' => '',
	'fields'      => array(
	    array(
			'type'    => 'submessage',
			'style'   => 'warning',
			'content' => ''. $new_badge['TXT'],
	    ),
	        array(
	          'type'  => 'backup',
	        ),
	    
	    ),
	));
	
}