<?php
if (!defined('ABSPATH')) {
	die('-1');
}

//全局&美化

/*
* ------------------------------------------------------------------------------
* 鼠标皮肤
* ------------------------------------------------------------------------------
*/

// 鼠标皮肤【蓝色精灵】
function shubiao(){ if (FACG('shubiao', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/shubiao1.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/shubiao2.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao' );
    
// 鼠标皮肤【寒雨剑锋】
function shubiao2(){ if (FACG('shubiao2', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr1.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr2.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao2' );
    
// 鼠标皮肤【幽灵琥珀】
function shubiao3(){ if (FACG('shubiao3', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr3.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr4.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao3' );
    
// 鼠标皮肤【红蓝对决】
function shubiao4(){ if (FACG('shubiao4', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr5.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr6.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao4' );
    
// 鼠标皮肤【返璞风筝】
function shubiao5(){ if (FACG('shubiao5', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr7.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr8.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao5' );
    
// 鼠标皮肤【翠色猫石】
function shubiao6(){ if (FACG('shubiao6', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr9.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr10.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao6' );
    
// 鼠标皮肤【黑白无常】
function shubiao7(){ if (FACG('shubiao7', false)) { ?>
    <style>body{cursor:url(<?php echo FACG('static_FACG');?>/img/arr11.png), default;}
    a:hover{cursor:url(<?php echo FACG('static_FACG');?>/img/arr12.png), pointer;}</style>
<?php }}add_action('wp_footer', 'shubiao7' );

/*
* ------------------------------------------------------------------------------
* 鼠标特效
* ------------------------------------------------------------------------------
*/

// 点击彩色粒子掉落
function caiselizidiaoluo(){ if (FACG('caiselizidiaoluo', false)) { ?>
    <script>
            "use strict";$(function(){function t(t,i){if(!(t instanceof i))throw new TypeError("Cannot call a class as a function")}var i=Object.assign||function(t){for(var i=1;i<arguments.length;i++){var n=arguments[i];for(var e in n)Object.prototype.hasOwnProperty.call(n,e)&&(t[e]=n[e])}return t},n=function(){function t(t,i){for(var n=0;n<i.length;n++){var e=i[n];e.enumerable=e.enumerable||!1,e.configurable=!0,"value"in e&&(e.writable=!0),Object.defineProperty(t,e.key,e)}}return function(i,n,e){return n&&t(i.prototype,n),e&&t(i,e),i}}(),e=function(){function e(n){var o=n.origin,r=n.speed,s=n.color,a=n.angle,h=n.context;t(this,e),this.origin=o,this.position=i({},this.origin),this.color=s,this.speed=r,this.angle=a,this.context=h,this.renderCount=0}return n(e,[{key:"draw",value:function(){this.context.fillStyle=this.color,this.context.beginPath(),this.context.arc(this.position.x,this.position.y,2,0,2*Math.PI),this.context.fill()}},{key:"move",value:function(){this.position.x=Math.sin(this.angle)*this.speed+this.position.x,this.position.y=Math.cos(this.angle)*this.speed+this.position.y+.3*this.renderCount,this.renderCount++}}]),e}(),o=function(){function i(n){var e=n.origin,o=n.context,r=n.circleCount,s=void 0===r?10:r,a=n.area;t(this,i),this.origin=e,this.context=o,this.circleCount=s,this.area=a,this.stop=!1,this.circles=[]}return n(i,[{key:"randomArray",value:function(t){var i=t.length;return t[Math.floor(i*Math.random())]}},{key:"randomColor",value:function(){var t=["8","9","A","B","C","D","E","F"];return"#"+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)+this.randomArray(t)}},{key:"randomRange",value:function(t,i){return(i-t)*Math.random()+t}},{key:"init",value:function(){for(var t=0;t<this.circleCount;t++){var i=new e({context:this.context,origin:this.origin,color:this.randomColor(),angle:this.randomRange(Math.PI-1,Math.PI+1),speed:this.randomRange(1,6)});this.circles.push(i)}}},{key:"move",value:function(){var t=this;this.circles.forEach(function(i,n){if(i.position.x>t.area.width||i.position.y>t.area.height)return t.circles.splice(n,1);i.move()}),0==this.circles.length&&(this.stop=!0)}},{key:"draw",value:function(){this.circles.forEach(function(t){return t.draw()})}}]),i}();(new(function(){function i(){t(this,i),this.computerCanvas=document.createElement("canvas"),this.renderCanvas=document.createElement("canvas"),this.computerContext=this.computerCanvas.getContext("2d"),this.renderContext=this.renderCanvas.getContext("2d"),this.globalWidth=window.innerWidth,this.globalHeight=window.innerHeight,this.booms=[],this.running=!1}return n(i,[{key:"handleMouseDown",value:function(t){var i=new o({origin:{x:t.clientX,y:t.clientY},context:this.computerContext,area:{width:this.globalWidth,height:this.globalHeight}});i.init(),this.booms.push(i),this.running||this.run()}},{key:"handlePageHide",value:function(){this.booms=[],this.running=!1}},{key:"init",value:function(){var t=this.renderCanvas.style;t.position="fixed",t.top=t.left=0,t.zIndex="999999999999999999999999999999999999999999",t.pointerEvents="none",t.width=this.renderCanvas.width=this.computerCanvas.width=this.globalWidth,t.height=this.renderCanvas.height=this.computerCanvas.height=this.globalHeight,document.body.append(this.renderCanvas),window.addEventListener("mousedown",this.handleMouseDown.bind(this)),window.addEventListener("pagehide",this.handlePageHide.bind(this))}},{key:"run",value:function(){var t=this;if(this.running=!0,0==this.booms.length)return this.running=!1;requestAnimationFrame(this.run.bind(this)),this.computerContext.clearRect(0,0,this.globalWidth,this.globalHeight),this.renderContext.clearRect(0,0,this.globalWidth,this.globalHeight),this.booms.forEach(function(i,n){if(i.stop)return t.booms.splice(n,1);i.move(),i.draw()}),this.renderContext.drawImage(this.computerCanvas,0,0,this.globalWidth,this.globalHeight)}}]),i}())).init()});
        </script>
<?php }}add_action('wp_footer', 'caiselizidiaoluo' );

//鼠标点击随机文字
function random(){ if (FACG('random', false)) { ?>
    <script>var a_idx=0;jQuery(document).ready(function($){$("body").click(function(e){var a=[<?php echo FACG('random_text',false);?>];var $i=$("<span/>").text(a[a_idx]);a_idx=(a_idx+1)%a.length;var x=e.pageX,y=e.pageY;function suijicolor(){return"#"+Math.floor(Math.random()*16777215).toString(16)}$i.css({"z-index":999999,"top":y-20,"left":x,"position":"absolute","font-weight":"bold",color:suijicolor()});$("body").append($i);$i.animate({"top":y-180,"opacity":0},1500,function(){$i.remove()})})});</script>
<?php }}add_action('wp_footer', 'random');

//鼠标点击屏幕炸金花效果
function zflower(){ if (FACG('zflower', false)) { ?>
    <script type="text/javascript" src="<?php echo FACG('static_FACG');?>/js/meme.js"></script><canvas class="fireworks" style="position:fixed;left:0;top:0;z-index:99999999;pointer-events:none;"></canvas><script type="text/javascript" src="<?php echo FACG('static_FACG');?>/js/anime.min.js"></script><script type="text/javascript" src="<?php echo FACG('static_FACG');?>/js/fireworks.js"></script>
<?php }}add_action('wp_footer', 'zflower');

//鼠标右键菜单样式美化
function mousebeautify(){ if (FACG('mousebeautify', false)) { ?>
    <style type="text/css">a {text-decoration: none;}div.usercm{background-repeat:no-repeat;background-position:center center;background-size:cover;background-color:#fff;font-size:13px!important;width:130px;-moz-box-shadow:1px 1px 3px rgba(0,0,0,.3);box-shadow:0 0 15px #333;position:absolute;display:none;z-index:10000;opacity:0.9; border-radius: 8px;}div.usercm ul{list-style-type:none;list-style-position:outside;margin:0px;padding:0px;display:block}div.usercm ul li{margin:0px;padding:0px;line-height:35px;}div.usercm ul li a{color:#666;padding:0 15px;display:block}div.usercm ul li a:hover{color:#fff;background:rgba(170,222,18,0.88)}div.usercm ul li a i{margin-right:10px}a.disabled{color:#c8c8c8!important;cursor:not-allowed}a.disabled:hover{background-color:rgba(255,11,11,0)!important}div.usercm{background:#fff !important;}</style>
	<div class="usercm" style="left: 199px; top: 5px; display: none;">
	<ul>
		<li><a href="/"><i class="fa fa-home fa-fw"></i><span>首页</span></a></li>
		<li><a href="javascript:void(0);" onclick="getSelect();"><i class="fa fa-copy fa-fw"></i><span>复制</span></a></li>
		<li><a href="javascript:history.go(1);"><i class="fa fa-arrow-right fa-fw"></i><span>前进</span></a></li>
		<li><a href="javascript:history.go(-1);"><i class="fa fa-arrow-left fa-fw"></i><span>后退</span></a></li>
		<li style="border-bottom:1px solid gray"><a href="javascript:window.location.reload();"><i class="fa fa-refresh fa-fw"></i><span>刷新</span></a></li>
		<li><a href="javascript:void(0);" onclick="benzhanSearch();"><i class="fa fa-search fa-fw"></i><span>本站搜索</span></a></li>
		<li><a href="javascript:void(0);"  onclick="baiduSearch();"><i class="fa fa-paw fa-fw"></i><span>百度搜索</span></a></li>
		<li><a href="javascript:void(0);" onclick="googleSearch();"><i class="fa fa-google fa-fw"></i><span>谷歌搜索</span></a></li>
		</ul>
	</div><script type="text/javascript">
	(function(a) {a.extend({mouseMoveShow: function(b) {var d = 0,c = 0,h = 0,k = 0,e = 0,f = 0;a(window).mousemove(function(g) {d = a(window).width();c = a(window).height();h = g.clientX;k = g.clientY;e = g.pageX;f = g.pageY;h + a(b).width() >= d && (e = e - a(b).width() - 5);k + a(b).height() >= c && (f = f - a(b).height() - 5);a("html").on({contextmenu: function(c) {3 == c.which && a(b).css({left: e,top: f}).show()},click: function() {a(b).hide()}})})},disabledContextMenu: function() {window.oncontextmenu = function() {return !1}}})})(jQuery);
	function getSelect() {"" == (window.getSelection ? window.getSelection() : document.selection.createRange().text) ? layer.msg("请选择需要百度的内容！") : document.execCommand("Copy")}
	function benzhanSearch() {var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;"" == a ? notyf("未选择需要本站搜索的内容！","warning") : window.open("/?s=" + a)}
	function baiduSearch() {var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;"" == a ? layer.msg("请选择需要百度的内容！") : window.open("https://www.baidu.com/s?wd=" + a)}
	function googleSearch() {var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;"" == a ? layer.msg("请选择需要谷歌的内容！") : window.open("https://www.google.com/search?q=" + a)}
	$(function() {for (var a = navigator.userAgent, b = "Android;iPhone;SymbianOS;Windows Phone;iPad;iPod".split(";"), d = !0, c = 0; c < b.length; c++) if (0 < a.indexOf(b[c])) {d = !1;break}d && ($.mouseMoveShow(".usercm"), $.disabledContextMenu())});</script>
<?php }}add_action('wp_footer', 'mousebeautify');

//点击搞笑文字特效
function gaoxiao(){ if (FACG('gaoxiao', false)) { ?>
    <script src="<?php echo FACG('static_FACG');?>/js/gaoxiao.js"></script>
<?php }}add_action('wp_footer', 'gaoxiao' );

//鼠标跟随光圈（蓝色）
function mouse_cursor(){ if (FACG('mouse_cursor', false)) { ?>
    <div class="mouse-cursor cursor-outer"></div><div class="mouse-cursor cursor-inner"></div>
    <script src="<?php echo FACG('static_FACG');?>/js/shubiao.js"></script>
    <style>.mouse-cursor {position: fixed;left: 0;top: 0;pointer-events: none;border-radius: 50%;-webkit-transform: translateZ(0);transform: translateZ(0);visibility: hidden;}.cursor-inner {margin-left: -3px;margin-top: -3px;width: 6px;height: 6px;z-index: 10000001;background: #123eed;-webkit-transition: width .3s ease-in-out,height .3s ease-in-out,margin .3s ease-in-out,opacity .3s ease-in-out;transition: width .3s ease-in-out,height .3s ease-in-out,margin .3s ease-in-out,opacity .3s ease-in-out;}.cursor-inner.cursor-hover {margin-left: -18px;margin-top: -18px;width: 36px;height: 36px;background: #123eed !important; opacity: .3;}.cursor-outer {margin-left: -15px; margin-top: -15px;width: 30px;height: 30px;border: 2px solid #123eed !important;-webkit-box-sizing: border-box;box-sizing: border-box;z-index: 10000000;opacity: .5;-webkit-transition: all .08s ease-out;transition: all .08s ease-out;}.cursor-outer.cursor-hover {opacity: 0;}.main-wrapper[data-magic-cursor=hide] .mouse-cursor {display: none;opacity: 0;visibility: hidden;position: absolute;z-index: -1111;}</style>
<?php }}add_action('wp_footer', 'mouse_cursor' );
    
//鼠标跟随光圈（绿色）
function mouse_cursor2(){ if (FACG('mouse_cursor2', false)) { ?>
    <div class="mouse-cursor cursor-outer"></div><div class="mouse-cursor cursor-inner"></div>
    <script src="<?php echo FACG('static_FACG');?>/js/shubiao.js"></script>
    <style>.mouse-cursor{position:fixed;left:0;top:0;pointer-events:none;border-radius:50%;-webkit-transform:translateZ(0);transform:translateZ(0);visibility:hidden}.cursor-inner{margin-left:-3px;margin-top:-3px;width:6px;height:6px;z-index:10000001;background:green;-webkit-transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out;transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out}.cursor-inner.cursor-hover{margin-left:-18px;margin-top:-18px;width:36px;height:36px;background:green !important;opacity:.3}.cursor-outer{margin-left:-15px;margin-top:-15px;width:30px;height:30px;border:2px solid green !important;-webkit-box-sizing:border-box;box-sizing:border-box;z-index:10000000;opacity:.5;-webkit-transition:all.08s ease-out;transition:all.08s ease-out}.cursor-outer.cursor-hover{opacity:0}.main-wrapper[data-magic-cursor=hide].mouse-cursor{display:none;opacity:0;visibility:hidden;position:absolute;z-index:-1111}</style>
<?php }}add_action('wp_footer', 'mouse_cursor2' );
    
//鼠标跟随光圈（粉色）
function mouse_cursor3(){ if (FACG('mouse_cursor3', false)) { ?>
    <div class="mouse-cursor cursor-outer"></div><div class="mouse-cursor cursor-inner"></div>
    <script src="<?php echo FACG('static_FACG');?>/js/shubiao.js"></script>
    <style>.mouse-cursor{position:fixed;left:0;top:0;pointer-events:none;border-radius:50%;-webkit-transform:translateZ(0);transform:translateZ(0);visibility:hidden}.cursor-inner{margin-left:-3px;margin-top:-3px;width:6px;height:6px;z-index:10000001;background:hotpink;-webkit-transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out;transition:width.3s ease-in-out,height.3s ease-in-out,margin.3s ease-in-out,opacity.3s ease-in-out}.cursor-inner.cursor-hover{margin-left:-18px;margin-top:-18px;width:36px;height:36px;background:hotpink !important;opacity:.3}.cursor-outer{margin-left:-15px;margin-top:-15px;width:30px;height:30px;border:2px solid hotpink !important;-webkit-box-sizing:border-box;box-sizing:border-box;z-index:10000000;opacity:.5;-webkit-transition:all.08s ease-out;transition:all.08s ease-out}.cursor-outer.cursor-hover{opacity:0}.main-wrapper[data-magic-cursor=hide].mouse-cursor{display:none;opacity:0;visibility:hidden;position:absolute;z-index:-1111}</style>
<?php }}add_action('wp_footer', 'mouse_cursor3' );

/*
* ------------------------------------------------------------------------------
* 动态背景
* ------------------------------------------------------------------------------
*/

//动态背景【五彩斑斓】
function dongtai1(){ if (FACG('dongtai1', false)) { ?>
<div id="bubble"><canvas width="1494" height="815" style="display: block; position: fixed; top: 0px; left: 0px; z-index: -2;"></canvas></div>
<script>class BGBubble{constructor(i){this.defaultOpts={id:"",num:20,start_probability:.1,radius_min:1,radius_max:2,radius_add_min:.3,radius_add_max:.5,opacity_min:.3,opacity_max:.5,opacity_prev_min:.003,opacity_prev_max:.005,light_min:40,light_max:70,is_same_color:!1,background:"#f1f3f4"},"[object Object]"==Object.prototype.toString.call(i)?this.userOpts={...this.defaultOpts,...i}:this.userOpts={...this.defaultOpts,id:i},this.color=this.random(0,360),this.bubbleNum=[],this.requestAnimationFrame=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||window.msRequestAnimationFrame,this.cancelAnimationFrame=window.cancelAnimationFrame||window.mozCancelAnimationFrame}random(i,t){return Math.random()*(t-i)+i}initBubble(i,t){const a=window.innerWidth,s=window.innerHeight,n=this.userOpts,e=this.random(n.light_min,n.light_max);this.bubble={x:this.random(0,a),y:this.random(0,s),radius:this.random(n.radius_min,n.radius_max),radiusChange:this.random(n.radius_add_min,n.radius_add_max),opacity:this.random(n.opacity_min,n.opacity_max),opacityChange:this.random(n.opacity_prev_min,n.opacity_prev_max),light:e,color:`hsl(${t?i:this.random(0,360)},100%,${e}%)`}}bubbling(i,t,a){!this.bubble&&this.initBubble(t,a);const s=this.bubble;i.fillStyle=s.color,i.globalAlpha=s.opacity,i.beginPath(),i.arc(s.x,s.y,s.radius,0,2*Math.PI,!0),i.closePath(),i.fill(),i.globalAlpha=1,s.opacity-=s.opacityChange,s.radius+=s.radiusChange,s.opacity<=0&&this.initBubble(t,a)}createCanvas(){this.canvas=document.createElement("canvas"),this.ctx=this.canvas.getContext("2d"),this.canvas.style.display="block",this.canvas.width=window.innerWidth,this.canvas.height=window.innerHeight,this.canvas.style.position="fixed",this.canvas.style.top="0",this.canvas.style.left="0",this.canvas.style.zIndex="-1",document.getElementById(this.userOpts.id).appendChild(this.canvas),window.onresize=(()=>{this.canvas.width=window.innerWidth,this.canvas.height=window.innerHeight})}start(){const i=window.innerWidth,t=window.innerHeight;this.color+=.1,this.ctx.fillStyle=this.defaultOpts.background,this.ctx.fillRect(0,0,i,t),this.bubbleNum.length<this.userOpts.num&&Math.random()<this.userOpts.start_probability&&this.bubbleNum.push(new BGBubble),this.bubbleNum.forEach(i=>i.bubbling(this.ctx,this.color,this.userOpts.is_same_color));const a=this.requestAnimationFrame;this.myReq=a(()=>this.start())}destory(){(0,this.cancelAnimationFrame)(this.myReq),window.onresize=null}}const bubbleDemo=new BGBubble("bubble");bubbleDemo.createCanvas(),bubbleDemo.start();function nofind(){var img=event.srcElement;img.src="";img.onerror=null;
}</script>
<?php }}add_action('wp_footer', 'dongtai1' );

//动态背景【符号元素】
function dongtai2(){ if (FACG('dongtai2', false)) { ?>
<link rel="stylesheet" href="<?php echo FACG('static_FACG');?>/css/yuansufuhao.css" />
<script>$('head').before('<div class="container1"><div class="inner-container1"><div class="shape"></div></div><div class="inner-container1"><div class="shape"></div></div></div>');</script>
<script src="<?php echo FACG('static_FACG');?>/js/yuansufuhao.min.js"></script>
<script>$(document).ready(function(){var html='';for(var i=1;i<=50;i++){html+='<div class="shape-container--'+i+' shape-animation"><div class="random-shape"></div></div>'}document.querySelector('.shape').innerHTML+=html});</script>
</script>
<?php }}add_action('wp_footer', 'dongtai2' );

//动态背景【粒子连线】
function Snowfall2lz(){ if (FACG('Snowfall2lz', false)) { ?>
<script>
    !function () {
    function n(n, e, t) {
        return n.getAttribute(e) || t
    }
 
    function e(n) {
        return document.getElementsByTagName(n)
    }
 
    function t() {
        var t = e("script"), o = t.length, i = t[o - 1];
        return {l: o, z: n(i, "zIndex", -1), o: n(i, "opacity", .5), c: n(i, "color", "0,0,0"), n: n(i, "count", 99)}
    }
 
    function o() {
        a = m.width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth, c = m.height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
    }
 
    function i() {
        r.clearRect(0,0,a,c);var n,e,t,o,m,l;s.forEach(function(i,x){for(i.x+=i.xa,i.y+=i.ya,i.xa*=i.x>a||i.x<0?-1:1,i.ya*=i.y>c||i.y<0?-1:1,r.fillRect(i.x-.5,i.y-.5,1,1),e=x+1;e<u.length;e++)n=u[e],null!==n.x&&null!==n.y&&(o=i.x-n.x,m=i.y-n.y,l=o*o+m*m,l<n.max&&(n===y&&l>=n.max/2&&(i.x-=.03*o,i.y-=.03*m),t=(n.max-l)/n.max,r.beginPath(),r.lineWidth=t/2,r.strokeStyle="rgba("+d.c+","+(t+.2)+")",r.moveTo(i.x,i.y),r.lineTo(n.x,n.y),r.stroke()))}),x(i)}var a,c,u,m=document.createElement("canvas"),d=t(),l="c_n"+d.l,r=m.getContext("2d"),x=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||function(n){window.setTimeout(n,1e3/45)},w=Math.random,y={x:null,y:null,max:2e4};m.id=l,m.style.cssText="position:fixed;top:0;left:0;z-index:"+d.z+";opacity:"+d.o,e("body")[0].appendChild(m),o(),window.onresize=o,window.onmousemove=function(n){n=n||window.event,y.x=n.clientX,y.y=n.clientY},window.onmouseout=function(){y.x=null,y.y=null};for(var s=[],f=0;d.n>f;f++){var h=w()*a,g=w()*c,v=2*w()-1,p=2*w()-1;s.push({x:h,y:g,xa:v,ya:p,max:6e3})}u=s.concat([y]),setTimeout(function(){i()},100)}();
    </script>
<?php }}add_action('wp_footer', 'Snowfall2lz' );

//动态背景【四方科技】
function specially(){ if (FACG('specially', false)) { ?>
<style>
body {
    background-image: url("<?php echo FACG('static_FACG');?>/img/sfkj.svg");
    background-position-x: center;
    background-position-y: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
}
</style>
<?php }}add_action('wp_footer', 'specially' );

/*
* ------------------------------------------------------------------------------
* 手机背景
* ------------------------------------------------------------------------------
*/

//手机端背景图片【淡蓝遐想】
function backgroundtu1(){ if (FACG('backgroundtu1', false)) { ?>
    <style>@media screen and (max-width: 776px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/mp.jpg);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'backgroundtu1');

//手机端背景图片【熏衣彩云】
function backgroundtu2(){ if (FACG('backgroundtu2', false)) { ?>
    <style>@media screen and (max-width: 776px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/ce.jpg);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'backgroundtu2');

//手机端背景图片【遨游题海】
function backgroundtu3(){ if (FACG('backgroundtu3', false)) { ?>
    <style>@media screen and (max-width: 776px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/mp1.png);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'backgroundtu3');

//手机端夜间背景图片【末日审判】
function backgroundtu4(){ if (FACG('backgroundtu4', false)) { ?>
    <style>@media screen and (max-width: 776px){
            .dark-theme {
                background-image: url(<?php echo FACG('static_FACG');?>/img/pcd.png);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'backgroundtu4');

//自定义手机端网站背景图片
function back(){ if (FACG('back', false)) { ?>
    <style>@media screen and (max-width: 776px){
            body {
                background-image: url(<?php echo FACG('back_img_1',false);?>);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
            .dark-theme {
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-image: url(<?php echo FACG('back_img_2',false);?>);
                background-size: cover;
            }}}
    </style>
<?php }}add_action('wp_footer', 'back');

/*
* ------------------------------------------------------------------------------
* 侧边背景
* ------------------------------------------------------------------------------
*/

//【淡蓝遐想】
function shoujicebianlan1(){ if (FACG('shoujicebianlan1', false)) { ?>
    <style>@media (max-width: 767px){.mobile-navbar.show,.mobile-navbar.left{background-size: cover;background-repeat: no-repeat;background-position: center center;cursor: pointer;background-image:linear-gradient(rgba(255, 255,255,0),rgba(255,255,255, 0.3)),url(<?php echo FACG('static_FACG');?>/img/mp.jpg);}.mobile-nav-widget .box-body {background: var(--muted-border-color) !important;}}</style>
<?php }}add_action('wp_footer', 'shoujicebianlan1');

//【熏衣彩云】
function shoujicebianlan2(){ if (FACG('shoujicebianlan2', false)) { ?>
    <style>@media (max-width: 767px){.mobile-navbar.show,.mobile-navbar.left{background-size: cover;background-repeat: no-repeat;background-position: center center;cursor: pointer;background-image:linear-gradient(rgba(255, 255,255,0),rgba(255,255,255, 0.3)),url(<?php echo FACG('static_FACG');?>/img/ce.jpg);}.mobile-nav-widget .box-body {background: var(--muted-border-color) !important;}}</style>
<?php }}add_action('wp_footer', 'shoujicebianlan2');

//【遨游题海】
function shoujicebianlan3(){ if (FACG('shoujicebianlan3', false)) { ?>
    <style>@media (max-width: 767px){.mobile-navbar.show,.mobile-navbar.left{background-size: cover;background-repeat: no-repeat;background-position: center center;cursor: pointer;background-image:linear-gradient(rgba(255, 255,255,0),rgba(255,255,255, 0.3)),url(<?php echo FACG('static_FACG');?>/img/mp1.png);}.mobile-nav-widget .box-body {background: var(--muted-border-color) !important;}}</style>
<?php }}add_action('wp_footer', 'shoujicebianlan3');

//自定义侧边背景
function backside(){ if (FACG('backside', false)) { ?>
    <style>@media (max-width: 767px){.mobile-navbar.show,.mobile-navbar.left{background-size: cover;background-repeat: no-repeat;background-position: center center;cursor: pointer;background-image:linear-gradient(rgba(255, 255,255,0),rgba(255,255,255, 0.3)),url(<?php echo FACG('backside_img',false);?>);}.mobile-nav-widget .box-body {background: var(--muted-border-color) !important;}}</style>
<?php }}add_action('wp_footer', 'backside');

/*
* ------------------------------------------------------------------------------
* 网站背景
* ------------------------------------------------------------------------------
*/

//【炫彩夜空】
function pcbackgroundtu1(){ if (FACG('pcbackgroundtu1', false)) { ?>
    <style>@media screen and (min-width: 1200px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/pc.jpg);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'pcbackgroundtu1');

//【淡蓝遐想】
function pcbackgroundtu2(){ if (FACG('pcbackgroundtu2', false)) { ?>
    <style>@media screen and (min-width: 1200px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/pc2.jpg);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'pcbackgroundtu2');

//【遨游题海】
function pcbackgroundtu3(){ if (FACG('pcbackgroundtu3', false)) { ?>
    <style>@media screen and (min-width: 1200px){
            body {
                background-image: url(<?php echo FACG('static_FACG');?>/img/pc1.png);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'pcbackgroundtu3');

//【末日审判】
function pcbackgroundtu4(){ if (FACG('pcbackgroundtu4', false)) { ?>
    <style>@media screen and (min-width: 1200px){
            .dark-theme {
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-image: url(<?php echo FACG('static_FACG');?>/img/pcd.png);
                background-size: cover;
            }}
    </style>
<?php }}add_action('wp_footer', 'pcbackgroundtu4');

//自定义PC端网站背景图片
function pcback(){ if (FACG('pcback', false)) { ?>
    <style>@media screen and (min-width: 1200px){
            body {
                background-image: url(<?php echo FACG('pcback_img_1',false);?>);
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }
            .dark-theme {
                background-position-x: center;
                background-position-y: center;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-image: url(<?php echo FACG('pcback_img_2',false);?>);
                background-size: cover;
            }}}
    </style>
<?php }}add_action('wp_footer', 'pcback');

//会员开通弹窗背景图片
function huiyuanktbj(){ if (FACG('huiyuanktbj', false)) { ?>
    <style>/*仿哔哩哔哩弹窗背景*/
.payvip-modal {
    background-image: url(<?php echo FACG('huiyuanktbj_img',false);?>),url(<?php echo FACG('huiyuanktbj_img2',false);?>);
    background-position: 0 100%,100% 100%;
    background-repeat: no-repeat,no-repeat;
    background-size: 20%;
}</style>
<?php }}add_action('wp_footer', 'huiyuanktbj');

/*
* ------------------------------------------------------------------------------
* 飘落特效
* ------------------------------------------------------------------------------
*/

//樱花背景
function yinghua(){ if (FACG('yinghua', false)) { ?>
<script src="<?php echo FACG('static_FACG');?>/js/yinghua.js"></script>
<?php }}add_action('wp_footer', 'yinghua' );

//枫叶飘落特效
function fengye(){ if (FACG('fengye', false)) { ?>
    <script>var stop,staticx;var img=new Image();img.src="<?php echo FACG('static_FACG');?>/img/fengye.webp";function Sakura(x,y,s,r,fn){this.x=x;this.y=y;this.s=s;this.r=r;this.fn=fn}Sakura.prototype.draw=function(cxt){cxt.save();var xc=20*this.s/2;cxt.translate(this.x,this.y);cxt.rotate(this.r);cxt.drawImage(img,0,0,20*this.s,20*this.s);cxt.restore()};Sakura.prototype.update=function(){this.x=this.fn.x(this.x,this.y);this.y=this.fn.y(this.y,this.y);this.r=this.fn.r(this.r);if(this.x>window.innerWidth||this.x<0||this.y>window.innerHeight||this.y<0){this.r=getRandom("fnr");if(Math.random()>0.4){this.x=getRandom("x");this.y=0;this.s=getRandom("s");this.r=getRandom("r")}else{this.x=window.innerWidth;this.y=getRandom("y");this.s=getRandom("s");this.r=getRandom("r")}}};SakuraList=function(){this.list=[]};SakuraList.prototype.push=function(sakura){this.list.push(sakura)};SakuraList.prototype.update=function(){for(var i=0,len=this.list.length;i<len;i++){this.list[i].update()}};SakuraList.prototype.draw=function(cxt){for(var i=0,len=this.list.length;i<len;i++){this.list[i].draw(cxt)}};SakuraList.prototype.get=function(i){return this.list[i]};SakuraList.prototype.size=function(){return this.list.length};function getRandom(option){var ret,random;switch(option){case"x":ret=Math.random()*window.innerWidth;break;case"y":ret=Math.random()*window.innerHeight;break;case"s":ret=Math.random();break;case"r":ret=Math.random()*4;break;case"fnx":random=-0.5+Math.random()*1;ret=function(x,y){return x+0.5*random-1.7};break;case"fny":random=1.5+Math.random()*0.7;ret=function(x,y){return y+random};break;case"fnr":random=Math.random()*0.03;ret=function(r){return r+random};break}return ret}function startSakura(){requestAnimationFrame=window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||window.msRequestAnimationFrame||window.oRequestAnimationFrame;var canvas=document.createElement("canvas"),cxt;staticx=true;canvas.height=window.innerHeight;canvas.width=window.innerWidth;canvas.setAttribute("style","position: fixed;left: 0;top: 0;pointer-events: none;");canvas.setAttribute("id","canvas_sakura");document.getElementsByTagName("body")[0].appendChild(canvas);cxt=canvas.getContext("2d");var sakuraList=new SakuraList();for(var i=0;i<50;i++){var sakura,randomX,randomY,randomS,randomR,randomFnx,randomFny;randomX=getRandom("x");randomY=getRandom("y");randomR=getRandom("r");randomS=getRandom("s");randomFnx=getRandom("fnx");randomFny=getRandom("fny");randomFnR=getRandom("fnr");sakura=new Sakura(randomX,randomY,randomS,randomR,{x:randomFnx,y:randomFny,r:randomFnR});sakura.draw(cxt);sakuraList.push(sakura)}stop=requestAnimationFrame(function(){cxt.clearRect(0,0,canvas.width,canvas.height);sakuraList.update();sakuraList.draw(cxt);stop=requestAnimationFrame(arguments.callee)})}window.onresize=function(){var canvasSnow=document.getElementById("canvas_snow")};img.onload=function(){startSakura()};function stopp(){if(staticx){var child=document.getElementById("canvas_sakura");child.parentNode.removeChild(child);window.cancelAnimationFrame(stop);staticx=false}else{startSakura()}};</script>
<?php }}add_action('wp_footer', 'fengye');

//雪花飘落特效
function xuehua(){ if (FACG('xuehua', false)) { ?>
    <script type="text/javascript">(function($){$.fn.snow = function(options){var $flake = $('<div id="snowbox" />').css({'position': 'absolute','z-index':'9999', 'top': '-50px'}).html('&#10052;'),documentHeight 	= $(document).height(),documentWidth	= $(document).width(),defaults = {minSize		: 10,maxSize		: 20,newOn		: 1000,flakeColor	: "#AFDAEF" },options	= $.extend({}, defaults, options);var interval= setInterval( function(){var startPositionLeft = Math.random() * documentWidth - 100,startOpacity = 0.5 + Math.random(),sizeFlake = options.minSize + Math.random() * options.maxSize,endPositionTop = documentHeight - 200,endPositionLeft = startPositionLeft - 500 + Math.random() * 500,durationFall = documentHeight * 10 + Math.random() * 5000;$flake.clone().appendTo('body').css({left: startPositionLeft,opacity: startOpacity,'font-size': sizeFlake,color: options.flakeColor}).animate({top: endPositionTop,left: endPositionLeft,opacity: 0.2},durationFall,'linear',function(){$(this).remove()});}, options.newOn);};})(jQuery);$(function(){$.fn.snow({ minSize: 5, /* 定义雪花最小尺寸 */maxSize: 50,/* 定义雪花最大尺寸 */ newOn: 300  /* 定义密集程度，数字越小越密集 */});});</script>
<?php }}add_action('wp_footer', 'xuehua');

//全局灰色主题
function grey(){ if (FACG('grey', false)) { ?>
    <style>html{-webkit-filter: grayscale(100%);filter: grayscale(100%);}</style>
<?php }}add_action('wp_footer', 'grey');

//首页灰色主题
function grey_page(){ if (FACG('grey_page', false)) { ?>
    <style>html body.home{-webkit-filter: grayscale(100%);filter: grayscale(100%);}</style>
<?php }}add_action('wp_footer', 'grey_page');

/*
* ------------------------------------------------------------------------------
* 圣诞美化
* ------------------------------------------------------------------------------
*/

//暴风雪
function baofengxue(){ if (FACG('baofengxue', false)) { ?>
<div id="snow"></div>
<style>
#snow {    
    position: fixed;    
    top: 0;    
    width: 100%;    
    height: 100%;    
    z-index: 99999;    
    pointer-events: none; /* 添加这一行 */  
}
.snowflake {
  position: absolute;
  display: block;
  position: absolute;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  -webkit-transform: translateZ(0);
  -moz-transform: translateZ(0);
  -ms-transform: translateZ(0);
  -o-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
  background-image: -webkit-radial-gradient(
    center,
    circle farthest-corner,
    rgba(255, 255, 255, 1) 40%,
    rgba(255, 255, 255, 0) 100%
  );
  background-image: -moz-radial-gradient(
    center,
    circle farthest-corner,
    rgba(255, 255, 255, 1) 40%,
    rgba(255, 255, 255, 0) 100%
  );
  background-image: -ms-radial-gradient(
    center,
    circle farthest-corner,
    rgba(255, 255, 255, 1) 40%,
    rgba(255, 255, 255, 0) 100%
  );
  background-image: radial-gradient(
    center,
    circle farthest-corner,
    rgba(255, 255, 255, 1) 40%,
    rgba(255, 255, 255, 0) 100%
  );
}
</style>
<script>
// Happy Xmas! by @neave

var Snowflake = (function() {

	var flakes;
	var flakesTotal = 250;
	var wind = 0;
	var mouseX;
	var mouseY;

	function Snowflake(size, x, y, vx, vy) {
		this.size = size;
		this.x = x;
		this.y = y;
		this.vx = vx;
		this.vy = vy;
		this.hit = false;
		this.melt = false;
		this.div = document.createElement('div');
		this.div.classList.add('snowflake');
		this.div.style.width = this.size + 'px';
		this.div.style.height = this.size + 'px';
	}

	Snowflake.prototype.move = function() {
		if (this.hit) {
			if (Math.random() > 0.995) this.melt = true;
		} else {
			this.x += this.vx + Math.min(Math.max(wind, -10), 10);
			this.y += this.vy;
		}

		// Wrap the snowflake to within the bounds of the page
		if (this.x > window.innerWidth + this.size) {
			this.x -= window.innerWidth + this.size;
		}

		if (this.x < -this.size) {
			this.x += window.innerWidth + this.size;
		}

		if (this.y > window.innerHeight + this.size) {
			this.x = Math.random() * window.innerWidth;
			this.y -= window.innerHeight + this.size * 2;
			this.melt = false;
		}

		var dx = mouseX - this.x;
		var dy = mouseY - this.y;
		this.hit = !this.melt && this.y < mouseY && dx * dx + dy * dy < 2400;
	};

	Snowflake.prototype.draw = function() {
		this.div.style.transform =
		this.div.style.MozTransform =
		this.div.style.webkitTransform =
			'translate3d(' + this.x + 'px' + ',' + this.y + 'px,0)';
	};

	function update() {
		for (var i = flakes.length; i--; ) {
			var flake = flakes[i];
			flake.move();
			flake.draw();
		}
		requestAnimationFrame(update);
	}

	Snowflake.init = function(container) {
		flakes = [];

		for (var i = flakesTotal; i--; ) {
			var size = (Math.random() + 0.2) * 12 + 1;
			var flake = new Snowflake(
				size,
				Math.random() * window.innerWidth,
				Math.random() * window.innerHeight,
				Math.random() - 0.5,
				size * 0.3
			);
			container.appendChild(flake.div);
			flakes.push(flake);
		}
    
    container.onmousemove = function(event) {
	  	mouseX = event.clientX;
  		mouseY = event.clientY;
  		wind = (mouseX - window.innerWidth / 2) / window.innerWidth * 6;
  	};

	  container.ontouchstart = function(event) {
		  mouseX = event.targetTouches[0].clientX;
		  mouseY = event.targetTouches[0].clientY;
		  event.preventDefault();
  	};

  	window.ondeviceorientation = function(event) {
	  	if (event) {
		  	wind = event.gamma / 10;
  		}
  	};
    
  	update();
	};

	return Snowflake;

}());

window.onload = function() {
  setTimeout(function() {
  	Snowflake.init(document.getElementById('snow'));
  }, 500);
}
</script>
<?php }}add_action('wp_footer', 'baofengxue');

//3D逼真雪花
function snow3d(){ if (FACG('snow3d', false)) { ?>
    <script src="<?php echo FACG('static_FACG');?>/js/snow3d.js"></script>
<?php }}add_action('wp_footer', 'snow3d' );

//emoji掉落效果
function sdemoji(){ if (FACG('sdemoji', false)) { ?>
    <script>
const emoteList = ['🎄', '🍬', '❄️', '⛄️', '🎅🏻', '🔔', '🦌', '🎁', '🍩', '🎈', '🧦', '🍪']

let innerW, innerH

const setInnerSize = () => {
	innerW = window.innerWidth
	innerH = window.innerHeight
}
const JudgePC = () => {
	let userAgent
	if (window && window.navigator) {
		userAgent = window.navigator.userAgent;
	} else {
		return true;
	}

	const agents = ['Android', 'iPhone', 'SymbianOS', 'Windows Phone', 'iPod', 'iPad'];
	for (let i = 0; i < agents.length; i++) {
		if (userAgent.indexOf(agents[i]) >= 0) return false;
	}
	return true;
};

let isPc = JudgePC()
const createEmoteElement = () => {
	const fsRange = isPc ? [20, 16] : [14, 6]
	const fs = fsRange[0] + Math.round(Math.random() * fsRange[1])
	const left = Math.round(Math.random() * ((innerW - (fs / 2)) - (fs / 2)))
	const top = -fs - 10
	const opacity = ((Math.random() * 16 + 84) / 100).toFixed(2) - 0
	const transitionDuration = 2000 + Math.round(Math.random() * 2000);

	const emoteEl = $('<div></div>').css({
		position: 'fixed',
		color: '#fff',
		top: `${ top }px`,
		left: `${ left }px`,
		fontSize: `${fs }px`,
		opacity: opacity,
		zIndex: 9999,
		textShadow: `0 0 ${ fs / 3 }px #ffffffcc`,
		transition: `transform ${ transitionDuration }ms linear`
	}).html(emoteList[Math.round(Math.random() * (emoteList.length - 1))])

	return { emoteEl, emoteParams: { fs, left, top, opacity, transitionDuration } }
}

const setEmoteAnimate = () => {
	const { emoteEl, emoteParams } = createEmoteElement()
	$('body').append(emoteEl)

	const leftRange = isPc ? [-80, 80] : [-40, 40]
	const endLeft = emoteParams.left + leftRange[Math.round(Math.random())]
	const endTop = innerH - emoteEl.height() + Math.round(Math.random() * 10)
	const moveDuration = innerH * 10 + Math.round(Math.random() * 4000);
	const endScale = 1.2 + ((Math.round(Math.random() * 4) / 10).toFixed(2) - 0);
	const hideDuration = 1200 + Math.round(Math.random() * 2000);

	emoteEl.animate({ left: `${ endLeft }px`, top: `${ endTop }px`, }, moveDuration, 'linear', () => {
		emoteEl.css({ transform: `scale(${ endScale })` })
			.animate({ opacity: 0 }, hideDuration, 'linear', () => (emoteEl.remove()))
	})
}

let num = 0
const start = () => setInterval(() => {
	if (num % 10 === 0) {
		setInnerSize()
		isPc = JudgePC()
	}
	num += 1
	setEmoteAnimate()
}, isPc ? 320 : 600)

$(document).ready(() => start())

console.log('%c 枫次元 | 枫影 | https://facg.top ', 'color: #f4f4f4;background: #444; padding:5px 0;border-radius:2px;');

</script>
<?php }}add_action('wp_footer', 'sdemoji' );

//下雪特效
function xiaxueyx(){ if (FACG('xiaxueyx', false)) { ?>
    <script type="text/javascript">
    /* 控制下雪 */
    function snowFall(snow) {
        /* 可配置属性 */
        snow = snow || {};
        this.maxFlake = snow.maxFlake || <?php echo FACG('xxshuliang');?>   /* 最多片数 */
        this.flakeSize = snow.flakeSize || <?php echo FACG('xxxingzhuang');?>  /* 雪花形状 */
        this.fallSpeed = snow.fallSpeed || <?php echo FACG('xxsudu');?> /* 坠落速度 */
    }
    /* 兼容写法 */
    requestAnimationFrame = window.requestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        function(callback) { setTimeout(callback, 1000 / 60); };
 
    cancelAnimationFrame = window.cancelAnimationFrame ||
        window.mozCancelAnimationFrame ||
        window.webkitCancelAnimationFrame ||
        window.msCancelAnimationFrame ||
        window.oCancelAnimationFrame;
    /* 开始下雪 */
    snowFall.prototype.start = function(){
        /* 创建画布 */
        snowCanvas.apply(this);
        /* 创建雪花形状 */
        createFlakes.apply(this);
        /* 画雪 */
        drawSnow.apply(this)
    }
    /* 创建画布 */
    function snowCanvas() {
        /* 添加Dom结点 */
        var snowcanvas = document.createElement("canvas");
        snowcanvas.id = "snowfall";
        snowcanvas.width = window.innerWidth;
        snowcanvas.height = document.body.clientHeight;
        snowcanvas.setAttribute("style", "position:absolute; top: 0; left: 0; z-index: 1; pointer-events: none;");
        document.getElementsByTagName("body")[0].appendChild(snowcanvas);
        this.canvas = snowcanvas;
        this.ctx = snowcanvas.getContext("2d");
        /* 窗口大小改变的处理 */
        window.onresize = function() {
            snowcanvas.width = window.innerWidth;
            /* snowcanvas.height = window.innerHeight */
        }
    }
    /* 雪运动对象 */
    function flakeMove(canvasWidth, canvasHeight, flakeSize, fallSpeed) {
        this.x = Math.floor(Math.random() * canvasWidth);   /* x坐标 */
        this.y = Math.floor(Math.random() * canvasHeight);  /* y坐标 */
        this.size = Math.random() * flakeSize + 2;          /* 形状 */
        this.maxSize = flakeSize;                           /* 最大形状 */
        this.speed = Math.random() * 1 + fallSpeed;         /* 坠落速度 */
        this.fallSpeed = fallSpeed;                         /* 坠落速度 */
        this.velY = this.speed;                             /* Y方向速度 */
        this.velX = 0;                                      /* X方向速度 */
        this.stepSize = Math.random() / 30;                 /* 步长 */
        this.step = 0                                       /* 步数 */
    }
    flakeMove.prototype.update = function() {
        var x = this.x,
            y = this.y;
        /* 左右摆动(余弦) */
        this.velX *= 0.98;
        if (this.velY <= this.speed) {
            this.velY = this.speed
        }
        this.velX += Math.cos(this.step += .05) * this.stepSize;
 
        this.y += this.velY;
        this.x += this.velX;
        /* 飞出边界的处理 */
        if (this.x >= canvas.width || this.x <= 0 || this.y >= canvas.height || this.y <= 0) {
            this.reset(canvas.width, canvas.height)
        }
    };
    /* 飞出边界-放置最顶端继续坠落 */
    flakeMove.prototype.reset = function(width, height) {
        this.x = Math.floor(Math.random() * width);
        this.y = 0;
        this.size = Math.random() * this.maxSize + 2;
        this.speed = Math.random() * 1 + this.fallSpeed;
        this.velY = this.speed;
        this.velX = 0;
    };
    // 渲染雪花-随机形状（此处可修改雪花颜色！！！）
    flakeMove.prototype.render = function(ctx) {
        var snowFlake = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.size);
        snowFlake.addColorStop(0, "rgba(255, 255, 255, 0.9)");  /* 此处是雪花颜色，默认是白色 */
        snowFlake.addColorStop(.5, "rgba(255, 255, 255, 0.5)"); /* 若要改为其他颜色，请自行查 */
        snowFlake.addColorStop(1, "rgba(255, 255, 255, 0)");    /* 找16进制的RGB 颜色代码。 */
        ctx.save();
        ctx.fillStyle = snowFlake;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    };
    /* 创建雪花-定义形状 */
    function createFlakes() {
        var maxFlake = this.maxFlake,
            flakes = this.flakes = [],
            canvas = this.canvas;
        for (var i = 0; i < maxFlake; i++) {
            flakes.push(new flakeMove(canvas.width, canvas.height, this.flakeSize, this.fallSpeed))
        }
    }
    /* 画雪 */
    function drawSnow() {
        var maxFlake = this.maxFlake,
            flakes = this.flakes;
        ctx = this.ctx, canvas = this.canvas, that = this;
        /* 清空雪花 */
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (var e = 0; e < maxFlake; e++) {
            flakes[e].update();
            flakes[e].render(ctx);
        }
        /*  一帧一帧的画 */
        this.loop = requestAnimationFrame(function() {
            drawSnow.apply(that);
        });
    }
    /* 调用及控制方法 */
    var snow = new snowFall({maxFlake:500});
    snow.start();
</script>
<?php }}add_action('wp_footer', 'xiaxueyx' );

//导航栏彩灯
function sdd(){ if (FACG('sdd', false)) { ?>
    <div id="xiaojudeng">
   </div>
<script type="text/javascript">
var con = document.getElementById("xiaojudeng");
var width=document.body.clientWidth;
var j = Math.ceil(width/15) + 1;
for(var i=0; i<=j; i++){
       var crli = document.createElement("li");
    con.appendChild(crli);
}
</script>
<style>
/*小桔灯*/
  #xiaojudeng{
            position: fixed;
            z-index: 999;
            top: 50px; //到顶部的距离。
            pointer-events: none;
            width: 100%;
            height: 120px;
            white-space: nowrap;
            overflow: hidden;
        }
        #xiaojudeng li{
            display: inline-block;
            margin-top: 15px;
            margin-right: 50px;
            width: 15px;
            height: 30px;
            border-radius: 50%;
            position: relative;
        }
        #xiaojudeng li::after{
            content: '';
            position: absolute;
            top: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 12px;
            background-color: #727472;
            box-shadow: inset 0 0 3px #c3c3bd;
            border-radius: 10px;

        }
        #xiaojudeng li::before{
            content: '';
            position: absolute;
            top: -23px;
            left: 15px;
            width: 55px;
            height: 30px;
            border-bottom: 3px solid  #e7e7e7;
            border-radius: 50%;
        }
        #xiaojudeng li:nth-of-type(2n+1){
           animation: lan 2s  infinite;
        }#xiaojudeng li:nth-child(2n+2){
            animation: huang 2.2s infinite;
        }#xiaojudeng li:nth-child(3n+3){
            animation: zhi 1.8s infinite;
        }
       #xiaojudeng li:nth-child(4n+4){
        animation: lv 2.8s infinite;
       }

        @keyframes lan{
            0%,100%{
                background-color: rgba(4, 255, 242, 0.5);
            }
            50%{
                background-color: rgb(4, 255, 242);
                box-shadow: 0 0 10px rgb(4, 255, 242),
                0 0 30px rgb(4, 255, 242),
                0 0 50px rgb(4, 255, 242);              
            }
        }
        @keyframes huang{
            0%,100%{
                background-color: rgba(251, 255, 4,.5);
            }
            50%{
                background-color: rgb(251, 255, 4);
                box-shadow: 0 0 10px rgb(251, 255, 4),
                0 0 12px rgb(251, 255, 4),
                0 0 30px rgb(251, 255, 4);              
            }
        }
        @keyframes lv{
            0%,100%{
                background-color: rgba(33, 255, 4,.5);
            }
            50%{
                background-color: rgb(33, 255, 4);
                box-shadow: 0 0 10px rgb(33, 255, 4),
                0 0 12px rgb(33, 255, 4),
                0 0 30px rgb(33, 255, 4);              
            }
        }
        @keyframes zhi{
            0%,100%{
                background-color:  rgba(255, 4, 255,.5);
            }
            50%{
                background-color: rgb(255, 4, 255);
                box-shadow: 0 0 10px  rgb(255, 4, 255),
                0 0 25px  rgb(255, 4, 255),
                0 0 40px  rgb(255, 4, 255);              
            }
        }
</style>
<?php }}add_action('wp_footer', 'sdd' );

//圣诞帽
function sdm(){ if (FACG('sdm', false)) { ?>
    <style>
    /*头像框*/
.txgj {
    top: 2px;
    transform: scale(1.7);
    width: 90px;
    position: absolute;
    z-index: 1;
}

.top-user-info-box-name .txgj {
    left: -5px;
    transform: scale(1);
    top: 6px;
}

.post-meta-left .txgj {
    display: none;
}

.post-meta-left .avatar-parent .txgj {
    display: block;
    transform: scale(1.6);
    display: block;
    left: 0px !important;
}

.top-user-box-drop .avatar {
    border-radius: 50%;
}

.comment .gravatar img {
    border-radius: 50%;
}

/*用户中心头像圆形*/
.author-header .avatar-img {
    --this-size: 95px;
}

.author-header .avatar-img .avatar {
    border-radius: 50px;
    border: 4px solid var(--main-bg-color)
}
</style>
<script>
    //头像框
$(function () {
    $('.avatar-img ').prepend('<img src="<?php echo FACG('static_FACG');?>/img/new2.png" class="txgj">');
    $('.avatar-mini ').prepend('<img src="<?php echo FACG('static_FACG');?>/img/new2.png" class="txgj">');
    $('.comt-avatar mb10 ').prepend('<img src="<?php echo FACG('static_FACG');?>/img/new2.png" class="txgj">');
    $('.avatar-set-link').css('z-index', '1');
})
</script>
<?php }}add_action('wp_footer', 'sdm' );

/*
* ------------------------------------------------------------------------------
* 网站字体
* ------------------------------------------------------------------------------
*/

//网站字体
function font_size(){ if (FACG('font_size', false)) { ?>
    <style>@font-face{font-family: 'zti';src:  url(<?php echo FACG('font_size_url', false);?>);}body{font-family:'zti';}</style>
<?php }}add_action('wp_footer', 'font_size' );

/*
* ------------------------------------------------------------------------------
* 全局美化
* ------------------------------------------------------------------------------
*/

//猫耳朵
function fengsemaoer(){ if (FACG('fengsemaoer', false)) { ?>
    <style>
        /*猫耳朵*/
.dropdown-menu {
    margin-bottom: 10px;
    border: none;
    box-sizing: border-box;
    padding: 25px 12px 14px;
    border-radius: 8px;
    background: url(<?php echo FACG('fengsemaoer_img');?>) no-repeat 50%;
    -webkit-background-size: 100% 100%;
    -moz-background-size: 100% 100%;
    background-size: 100% 100%;
}
.float-btn.qrcode-btn .hover-show-con {
    width: 150px;
    top: -60px;
    padding: 30px 5px 12px;
    text-align: center;
}
    </style>
<?php }}add_action('wp_footer', 'fengsemaoer' );

//翻页按钮美化
function shuzifanye(){ if (FACG('shuzifanye', false)) { ?>
    <style>
/*翻页按钮*/
.pagenav .current {
    background: linear-gradient(90deg, #7de4d7 0%, #ff89ee 100%);
    color: #fff!important;
}
    </style>
<?php }}add_action('wp_footer', 'shuzifanye' );

//加载更多美化
function jiazaigd(){ if (FACG('jiazaigd', false)) { ?>
    <style>
/*点击更多按钮美化*/
.chat-next a, .theme-pagination .ajax-next a, .theme-pagination .order-ajax-next a {
    color: var(--muted-color);
    border-radius: 30px;
    padding: 6px 0px;
    background-color: var(--main-bg-color);
    display: block;
    opacity: 1;
    font-weight: bold;
    width: 130px;
    margin: auto;
    border: 2px solid <?php echo FACG('jiazaigdxuxian_color')?>;
    border-style: dashed;
    box-shadow: 0 0 4px 9px var(--main-bg-color);
}
.chat-next a:hover, .theme-pagination .ajax-next a:hover, .theme-pagination .order-ajax-next a:hover {
    opacity: 1;
    color: <?php echo FACG('jiazaigdzth_color')?>;
    box-shadow: 0 0 4px 9px #ffffff00;
    border: 2px solid <?php echo FACG('jiazaigdshixian_color')?>;
    background: linear-gradient(rgb(237 111 0 / 0%), rgb(255 244 244 / 0%)), url(<?php echo FACG('jiazaigd_img')?>) no-repeat 90% 100%/ 12% 100%;
}
    </style>
<?php }}add_action('wp_footer', 'jiazaigd' );

//边框细节优化
function biankuangxj(){ if (FACG('biankuangxj', false)) { ?>
    <style>
.navbar-top .navbar-right .sub-menu {
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.posts-item.card{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.zib-widget{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.plate-lists .plate-item{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.forum-posts{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.article{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
.main-shadow{
	-webkit-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	-moz-box-shadow: 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?> inset;
	box-shadow: inset 0 1px 4px 0 <?php echo FACG('biankuangxj_color',false);?>;
}
    </style>
<?php }}add_action('wp_footer', 'biankuangxj' );

//图标美化
function icon_js(){ if (FACG('icon_js', false)) { ?>
    <script src="<?php echo FACG('static_FACG');?>/js/svg-icon.js"></script>
<?php }}add_action('wp_footer', 'icon_js' );

//原神启动
function yuanshen(){ if (FACG('yuanshen', false)) { ?>
<style>
    body:after {
    content: " ";
    position: fixed;
    inset: 0;
    background-color: white;
    z-index: 999;
    background-image: url(<?php echo FACG('yuanshen_img',false);?>);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 30%;
    animation: fadeOut 3s;
    animation-fill-mode: forwards;
    -webkit-transition: fadeOut 3s;
    transition: fadeOut 3s;
    pointer-events: none;
}
@keyframes fadeOut {
  50% {
    opacity: 1;
  }
 
  100% {
    opacity: 0;
  }
}
</style>
<?php }}add_action('wp_footer', 'yuanshen' );

//导航&美化

/*
* ------------------------------------------------------------------------------
* logo滤镜
* ------------------------------------------------------------------------------
*/

//网站LOGO扫光
function logoflash(){ if (FACG('logoflash', false)) { ?>
    <style>.navbar-brand{position:relative;overflow:hidden;margin: 0 0 0 0;}.navbar-brand:before{content:""; position: absolute; left: -665px; top: -460px; width: 200px; height: 15px; background-color: rgba(255,255,255,.5); -webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg); -webkit-animation: searchLights 6s ease-in 0s infinite; -o-animation: searchLights 6s ease-in 0s infinite; animation: searchLights 6s ease-in 0s infinite;}@-moz-keyframes searchLights{50%{left: -100px; top: 0;} 65%{left: 120px; top: 100px;}}@keyframes searchLights{40%{left: -100px; top: 0;} 60%{left: 120px; top: 100px;} 80%{left: -100px; top: 0;}}</style>
<?php }}add_action('wp_footer', 'logoflash');

//LOGO色彩渐变
function logogradient(){ if (FACG('logogradient', false)) { ?>
    <style>.navbar-logo{animation: hue 4s infinite;}@keyframes hue {from {filter: hue-rotate(0deg);}to {filter: hue-rotate(-360deg);}}</style>
<?php }}add_action('wp_footer', 'logogradient');

//LOGO反色
function logo2(){ if (FACG('logo2', false)) { ?>
<style>.navbar-logo{filter:invert(1);}</style>
<?php }}add_action('wp_footer', 'logo2' );

//LOGO夜间反色
function logo3(){ if (FACG('logo3', false)) { ?>
<style>.dark-theme .navbar-logo{filter:invert(1);}</style>
<?php }}add_action('wp_footer', 'logo3' );

//LOGO淡绿色阴影
function logo4(){ if (FACG('logo4', false)) { ?>
<style>.navbar-logo{filter:drop-shadow(0 0 10px dodgerblue);}</style>
<?php }}add_action('wp_footer', 'logo4' );

/*
* ------------------------------------------------------------------------------
* 导航栏内容
* ------------------------------------------------------------------------------
*/

//导航栏字体加粗
function navigation(){ if (FACG('navigation', false)) { ?>
    <style>ul.nav {font-weight: <?php echo FACG('navigation_num');?>;}</style>
<?php }}add_action('wp_footer', 'navigation');

//标题样式美化
function navbiaoti(){ if (FACG('navbiaoti', false)) { ?>
<style>.navbar-nav>li:first-child:before{width:30px;}.navbar-nav>li:before{width:60px;top:23px;background:rgba(0,0,0,0);height:4px;left:10px;border-radius:unset;}.navbar-top li.current-menu-item>a, .navbar-top li:hover>a {color: unset;}</style>
<?php }}add_action('wp_footer', 'navbiaoti' );

//禁用搜索功能
function nosearch(){ if (FACG('nosearch', false)) { ?>
<script>$(document).ready(function(){$("li.relative").css("display","none")})</script>
<?php }}add_action('wp_footer', 'nosearch' );

//FPS帧率显示
function facg_fps(){ if (FACG('show_fps', false)) { ?>
    <script>$('body').before('<div id="fps" style="font-size:<?php echo FACG('show_fps_dx',false);?>px !important;z-index:10000;position:fixed;margin-top:<?php echo FACG('show_fps_wz',false);?>px;left:3;font-weight:bold;-webkit-background-clip: text;color: <?php echo FACG('show_fps_color',false);?>;"></div>');var showFPS = (function(){var requestAnimationFrame =window.requestAnimationFrame ||window.webkitRequestAnimationFrame ||window.mozRequestAnimationFrame ||window.oRequestAnimationFrame ||window.msRequestAnimationFrame ||function(callback) {window.setTimeout(callback, 1000/60);};var e,pe,pid,fps,last,offset,step,appendFps;fps = 0;last = Date.now();step = function(){offset = Date.now() - last;fps += 1;if( offset >= 1000 ){last += offset;appendFps(fps);fps = 0;}requestAnimationFrame( step );};appendFps = function(fps){ $('#fps').html(fps+'FPS');};step();})();</script>
<?php }}add_action('wp_footer', 'facg_fps');

//自定义导航栏皮肤
function usernavbg8(){ if (FACG('usernavbg8', false)) { ?>
<style>@media screen and (min-width: 1000px){.header-layout-1{position:relative;background-image:url("<?php 
	echo FACG('usernavbg88');
	?>");background-position:center right;background-size:100% 100%;}}</style>
<?php }}add_action('wp_footer', 'usernavbg8' );

//搜索背景
function ssbj(){ if (FACG('ssbj', false)) { ?>
<style>
.navbar-search.show {
    background-image: url(<?php echo FACG('ssbj_img');?>);
}
</style>
<?php }}add_action('wp_footer', 'ssbj' );

//右上角开通会员炫彩色
function hyktxc(){ if (FACG('hyktxc', false)) { ?>
<style>.payvip-icon{color: #ffffff;--this-color: #ffffff;background:linear-gradient(135deg,#ff7faf91 10%,#43b2ff 100%);}.vip-theme1{background:linear-gradient(135deg,#ff7faf91 10%,#43b2ff 100%);}.vip-theme2{background:linear-gradient(43deg,#ff6ac3 0%,#465dff 46%,#72e699 100%);color:#e4e2fb;}</style>
<?php }}add_action('wp_footer', 'hyktxc' );

//局部&美化

/*
* ------------------------------------------------------------------------------
* 用户头像
* ------------------------------------------------------------------------------
*/

//用户头像美化
function facg_avatar(){ if (FACG('facg_avatar', false)) { ?>
    <style>.avatar-img{border-radius: 50%; animation: light 4s ease-in-out infinite; transition: 0.5s;}.avatar-img:hover{transform: scale(1.15) rotate(720deg);}@keyframes light{0%{box-shadow: 0 0 4px #f00;} 25%{box-shadow: 0 0 16px #0f0;} 50%{box-shadow: 0 0 4px #00f;} 75%{box-shadow: 0 0 16px #0f0;} 100%{box-shadow: 0 0 4px #f00;}}</style>
<?php }}add_action('wp_footer', 'facg_avatar');

//彩色昵称
function csnc(){ if (FACG('csnc', false)) { ?>
<style>
.display-name{
background-image: -webkit-linear-gradient(90deg, #07c160, #fb6bea 25%, #3aedff 50%, #fb6bea 75%, #28d079);
-webkit-text-fill-color: transparent;
-webkit-background-clip: text;
background-size: 100% 600%;
animation: wzw 10s linear infinite;
}
@keyframes wzw {
0% {
background-position: 0 0;
}
100% {
background-position: 0 -300%;
}
}
</style>
<?php }}add_action('wp_footer', 'csnc' );

//昵称抖动
function dydd(){ if (FACG('dydd', false)) { ?>
<style>
.display-name {
  animation: animate 0.5s linear infinite;
}

@keyframes animate {
  0%, 100% {
    text-shadow: -1.5px -1.5px 0 #0ff, 1.5px 1.5px 0 #f00;
  }
  25% {
    text-shadow: 1.5px 1.5px 0 #0ff, -1.5px -1.5px 0 #f00;
  }
  50% {
    text-shadow: 1.5px -1.5px 0 #0ff, 1.5px -1.5px 0 #f00;
  }
  75% {
    text-shadow: -1.5px 1.5px 0 #0ff, -1.5px 1.5px 0 #f00;
  }
}</style>
<?php }}add_action('wp_footer', 'dydd' );


//用户摇摆
function facg_avatar_yb(){ if (FACG('facg_avatar_yb', false)) { ?>
    <style>/*小工具头像跳动*/
.user-avatar .avatar-img, .img-ip:hover, .w-a-info img {
   -webkit-animation: swing 3s .4s ease both;
   -moz-animation: swing 3s .4s ease both;
}
@-webkit-keyframes swing {
   20%, 40%, 60%, 80%, 100% {
       -webkit-transform-origin:top center
   }
   20% {
       -webkit-transform:rotate(15deg)
   }
   40% {
       -webkit-transform:rotate(-10deg)
   }
   60% {
       -webkit-transform:rotate(5deg)
   }
   80% {
       -webkit-transform:rotate(-5deg)
   }
   100% {
       -webkit-transform:rotate(0deg)
   }
}
@-moz-keyframes swing {
   20%, 40%, 60%, 80%, 100% {
       -moz-transform-origin:top center
   }
   20% {
       -moz-transform:rotate(15deg)
   }
   40% {
       -moz-transform:rotate(-10deg)
   }
   60% {
       -moz-transform:rotate(5deg)
   }
   80% {
       -moz-transform:rotate(-5deg)
   }
   100% {
       -moz-transform:rotate(0deg)
   }
}</style>
<?php }}add_action('wp_footer', 'facg_avatar_yb');

 /*
* ------------------------------------------------------------------------------
* 左侧美化
* ------------------------------------------------------------------------------
*/

// 左侧显示联系站长按钮
function qq(){ if (FACG('qq', false)) { ?>
    <style>
        .contact-help-qq{position: fixed;z-index: 99999;left: 0;top: calc(30% - 30px);margin-top: -36px;width: 28px;height: 85px;transition: all .3s;
            font-size: 12px;background: var(--main-bg-color);border-radius: 0 7px 7px 0; padding: 8px 7px;line-height: 14px;}@media screen and (max-width: 768px){.contact-help-qq{display:none;}}</style>
    <script src="<?php echo FACG('static_FACG');?>/js/qq.js"></script>
    <a href="<?php echo FACG('qq_url');?>"target="_blank" class="contact-help-qq" style="font-weight:700;"><?php echo FACG('qq_text');?><svg class="icon" aria-hidden="true"><use xlink:href="#icon-QQ"></use></svg></a>
<?php }}add_action('wp_head', 'qq' );

 /*
* ------------------------------------------------------------------------------
* 右侧美化
* ------------------------------------------------------------------------------
*/

//右侧悬浮按钮图片
function suspension(){ if (FACG('suspension', false)) { ?>
    <style>
        span.float-btn.more-btn.hover-show.nowave {
            margin-top: 0
        }

        .float-right.round.position-bottom {
            background: #fff;
            border-radius: var(--main-radius);
            transition: 0s;
            right: 1px;
            bottom: 170px;
            border-radius: 20px 0 0 20px;
            box-shadow: -5px 3px 10px 0 rgb(5 5 5 / 15%)
        }

        .float-right.round .float-btn {
            border-radius: 8px 0 0 17px
        }

        .float-right .float-btn {
            background: #fff
        }

        .float-right.round.position-bottom::before {
            content: '';
            width: 40px;
            height: 60px;
            background: url(<?php echo FACG('suspension_img')?>);
            background-size: cover;
            display: block;
            margin: 8px 0 0 0;
        }


        .dark-theme .float-right.round.position-bottom {
            background: #414141;
            border: 1px solid #4a4a4a;
            transition: 0s
        }

        .dark-theme .float-right .float-btn {
            background: #414141
        }

        .dark-theme .float-right.round.position-bottom a:hover {
            background: #505255;
            --this-color: var(--muted-2-color)
        }

        .dark-theme .float-right.round.position-bottom span:hover {
            background: #505255;
            --this-color: var(--muted-2-color)
        }

        span.newadd-btns.hover-show.float-btn.add-btn .hover-show-con.dropdown-menu.drop-newadd>a:hover {
            background-color: #d8d8d836;
            border-radius: 8px
        }

        a.float-btn.ontop.fade {
            display: none
        }
    </style>
<?php }}add_action('wp_footer', 'suspension' );
 
//单色滚动条
function scroll(){ if (FACG('scroll', false)) { ?>
    <style>::-webkit-scrollbar-thumb{background-color:<?php echo FACG('scroll_color',false);?>;height:50px;  outline-offset:-2px;  outline:2px solid #fff;  -webkit-border-radius:4px;  border: 2px solid #fff;  }  ::-webkit-scrollbar{  width:8px;  height:8px;  }  ::-webkit-scrollbar-track-piece{  background-color:#fff;  -webkit-border-radius:0;  }</style>
<?php }}add_action('wp_footer', 'scroll');

//渐变色滚动条
function scrollbar(){ if (FACG('scrollbar', false)) { ?>
    <style>::-webkit-scrollbar {width : 6px;height: 1px;}::-webkit-scrollbar-thumb {border-radius:10px;background-color: <?php echo FACG('scrollbar_color',false);?>;background-image: linear-gradient(0deg, <?php echo FACG('scrollbar_color',false);?> 0%, <?php echo FACG('scrollbar_color_1',false);?> 80%, <?php echo FACG('scrollbar_color_2',false);?> 100%);::-webkit-scrollbar-track {box-shadow   : inset 0 0 10px rgb(0 0 0 / 10%);background   : #ededed;}</style>
<?php }}add_action('wp_footer', 'scrollbar' );
 
//彩色滚动条(更优雅)
function scroll_bar(){ if (FACG('scroll_bar', false)) { ?>
    <style>::-webkit-scrollbar {width: <?php echo FACG('scroll_bar_px',false);?>px;  height: 1px;}::-webkit-scrollbar-thumb {background-color: #12b7f5;background-image: -webkit-linear-gradient(45deg, rgba(255, 93, 143, 1) 25%, transparent 25%, transparent 50%, rgba(255, 93, 143, 1) 50%, rgba(255, 93, 143, 1) 75%, transparent 75%, transparent);}::-webkit-scrollbar-track {-webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);background: #f6f6f6;}</style>
<?php }}add_action('wp_footer', 'scroll_bar');
 
//可爱调皮小猫
function cat(){ if (FACG('cat', false)) { ?>
    <style>#maomao{position:fixed;bottom:40px;right:-5px;width:57px;height:70px;background-image:url(<?php echo FACG('static_FACG');?>/img/mao.svg);background-position:center;background-size:cover;background-repeat:no-repeat;transition:background .3s;z-index:99999999999999}#maomao:hover{background-position:60px 50%;}</style><div id="maomao" onmouseout="duoMaomao()" style="bottom: 60vh;"></div><script>var randomNum =function(minNum,maxNum) {switch (arguments.length) {case 1:return parseInt(Math.random() *minNum + 1,10);break;case 2:return parseInt(Math.random() *(maxNum - minNum + 1) + minNum,10);break;default:return 0;break;};};var duoMaomao =function() {var maomao =$('#maomao');maomao.css('bottom',randomNum(1,90) + 'vh');};</script>
<?php }}add_action('wp_footer', 'cat');

//悬浮按钮美化
function xfan(){ if (FACG('xfan', false)) { ?>
    <style>/*悬浮按钮渐变颜色*/
.float-right .float-btn {
    width: 40px;
    line-height: 40px;
    display: block;
    font-size: 1.4em;
    --this-color: #fff;
    --this-bg: var(--float-btn-bg);
    background: linear-gradient(90deg, #fdfffc73 0%, #ff5683 100%);
    position: relative;
    color: var(--this-color)!important;
}
/*悬浮按钮圆形样式*/
.float-right.round .float-btn {
    margin-top: 5px;
    border-radius: 20px;
}</style>
<?php }}add_action('wp_footer', 'xfan');

//悬浮按钮美化-新
function xfanx(){ if (FACG('xfanx', false)) { ?>
    <style>/*悬浮按钮渐变颜色*/
/*悬浮按钮*/
.float-right.round .float-btn {
    position: relative;
    display: block;
    height: 56px;
    width: 56px;
    padding: 20px 4px;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
    margin-bottom: 8px;
    font-size: 14px;
    line-height: 20px;
    text-align: center;
    color: #FFD1D8;
    background-color: #ffffff;
    -webkit-box-shadow: 0 0 6px 0 #FFD1D8;
    -moz-box-shadow: 0 0 6px 0 #FFD1D8;
    box-shadow: 0 0 6px 0 #FFD1D8;
    cursor: pointer;
}
.fa-toggle-theme::after, .fa-toggle-theme::before {
    font-size: 18px;
}
.float-right.round:hover .float-btn:hover {
    -moz-box-shadow: 0 0 6px 0 #FFB5C3;
    box-shadow: 0 0 6px 0 #fc6976;
        background-color: #FFB5C3;
}
.float-btn .hover-show-con {
    right: 40px;
    margin-right: 25px;
}
            /*按钮上方小图*/
            .float-right.round.position-bottom::before {
                content: '';
                width: 50px;
                height: 60px;
                background: url(<?php echo FACG('suspension_imgss')?>);
                background-size: cover;
                display: block;
            }</style>
<?php }}add_action('wp_footer', 'xfanx');

 /*
* ------------------------------------------------------------------------------
* 底部美化
* ------------------------------------------------------------------------------
*/

//二维码1
function erweima1(){ if (FACG('erweima1', false)) { ?>
<style>.footer-miniimg{filter:hue-rotate(80deg);}</style>
<?php }}add_action('wp_footer', 'erweima1' );

//二维码2
function erweima2(){ if (FACG('erweima2', false)) { ?>
<style>.footer-miniimg{filter:invert(1);}</style>
<?php }}add_action('wp_footer', 'erweima2' );

//二维码3
function erweima3(){ if (FACG('erweima3', false)) { ?>
<style>.footer-miniimg{filter:drop-shadow(0 0 10px dodgerblue);}</style>
<?php }}add_action('wp_footer', 'erweima3' );

//底线
function dixian(){ if (FACG('dixian', false)) { ?>
<script>$('footer').before('<img id="dixian" src="<?php echo FACG('static_FACG');?>/img/dixian2.gif"/><style>#dixian{width:1000px;height:70px;margin-left:19%;}@media screen and (max-width: 800px){#dixian{width:1000px;height:50px;margin-left:6%;}}</style>');</script>
<?php }}add_action('wp_footer', 'dixian' );

//底部添加蓝色波浪
function wave (){if (FACG('wave', false)) {
    if(!is_page('user-sign')){
        ?>
        <div class="ape_layout"><svg class="editorial"xmlns="http://www.w3.org/2000/svg"xmlns:xlink="http://www.w3.org/1999/xlink"viewBox="0 24 150 28"preserveAspectRatio="none"><defs><path id="gentle-wave"d="M-160 44c30 0
58-18 88-18s
58 18 88 18
58-18 88-18
58 18 88 18
v44h-352z"/></defs><g class="parallax"><use xlink:href="#gentle-wave"x="50"y="0"fill="#4579e2"/><use xlink:href="#gentle-wave"x="50"y="3"fill="#3461c1"/><use xlink:href="#gentle-wave"x="50"y="6"fill="#2d55aa"/></g></svg></div><style type='text/css'>.parallax>use{animation:move-forever 12s linear infinite}.parallax>use:nth-child(1){animation-delay:-2s}.parallax>use:nth-child(2){animation-delay:-2s;animation-duration:5s}.parallax>use:nth-child(3){animation-delay:-4s;animation-duration:3s}@keyframes move-forever{0%{transform:translate(-90px,0%)}100%{transform:translate(85px,0%)}}.ape_layout{width:100%;height:40px;position:relative;overflow:hidden;z-index:1;background:var(--footer-bg)}.editorial{display:block;width:100%;height:40px;margin:0}</style>
        <?php
    }
}
}add_action('wp_footer', 'wave');

//蒲公英
function plbj5(){ if (FACG('plbj5', false)) { ?>
<link rel="stylesheet" href="<?php echo FACG('static_FACG');?>/css/pugongying.css">
<div class="dandelion"><span class="smalldan"></span><span class="bigdan"></span></div>  
<?php }}add_action('wp_footer', 'plbj5' );

// 网站运行时间
function timeauthor(){ if (FACG('timeauthor', false)) { ?>
    <script>$('footer').before('<span id="bottomtime"></span>');
    function NewDate(str) {
    str = str.split('-');
    var date = new Date();
    date.setUTCFullYear(str[0], str[1] - 1, str[2]);
    date.setUTCHours(0, 0, 0, 0);
    return date;}
    function momxc() {
    var birthDay =NewDate("<?php 
        echo FACG('timeauthor1');
        ?>");
    var today=new Date();
    var timeold=today.getTime()-birthDay.getTime();
    var sectimeold=timeold/1000
    var secondsold=Math.floor(sectimeold);
    var msPerDay=24*60*60*1000; var e_daysold=timeold/msPerDay;
    var daysold=Math.floor(e_daysold);
    var e_hrsold=(daysold-e_daysold)*-24;
    var hrsold=Math.floor(e_hrsold);
    var e_minsold=(hrsold-e_hrsold)*-60;
    var minsold=Math.floor((hrsold-e_hrsold)*-60); var seconds=Math.floor((minsold-e_minsold)*-60).toString();
    seconds=seconds>9?seconds:"0"+seconds;//秒数补全
    minsold=minsold>9?minsold:"0"+minsold;//分数补全
    hrsold=hrsold>9?hrsold:"0"+hrsold;//时数补全
    document.getElementById("bottomtime").innerHTML = "本站已安全运行"+daysold+"天 "+hrsold+"时 "+minsold+"分 "+seconds+"秒";
    setTimeout(momxc, 1000);}momxc();
    $(document).ready(function(){if(window.screen.width < window.screen.height){
    $("#bottomtime").hide();}else{$("#bottomtime").show();}})</script>
    <style>#bottomtime{z-index:99999;animation:change 10s infinite;font-size:11px; color:cornflowerblue;display:block;bottom:7px;left:34%;width:250px;position:fixed;}@keyframes change{0%{color:#5cb85c;}25%{color:#556bd8;}50%{color:#e40707;}75%{color:#66e616;}100% {color:#67bd31;}}</style>
<?php }}add_action('wp_footer', 'timeauthor' );

//活动倒计时
function hddjs(){ if (FACG('hddjs', false)) { ?>
<!-- Made by Juanyi -->
<!-- 和子比有兼容问题的记得注释掉，如果没引用Jquery记得把注释取消 -->
<!-- <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.7.1/jquery.js"></script> -->
<script src="https://cdn.bootcdn.net/ajax/libs/js-cookie/3.0.5/js.cookie.js"></script>
<style>
    /* 活动背景图片 */
    .vip-login-tip {
        background-image: url(<?php echo FACG('hddjs_img',false);?>)
    }
</style>
<script>
//快捷施法专区，懒人福音⬇️⬇️⬇️
    // 结束时间
    var endtime = "<?php echo FACG('hddjs_text_3',false);?>";
    endtime = new Date(endtime);
    // 活动内容
    var viptitle = "<?php echo FACG('hddjs_text_1',false);?>";
    var vipsubtitle = "<?php echo FACG('hddjs_text_2',false);?>";
    var payvip = "<?php echo FACG('hddjs_text_4',false);?>";
    // 多少天时间显示一次
    var displaytime = 1;
//快捷施法专区，懒人福音⬆️⬆️⬆️
    function addZero(i){return i<10?"0"+i:i+""}function countDown(){var nowtime=new Date();var lefttime=parseInt((endtime.getTime()-nowtime.getTime())/1000);var d=addZero(parseInt(lefttime/(24*60*60)));var h=addZero(parseInt(lefttime/(60*60)%24));var m=addZero(parseInt(lefttime/60%60));var s=addZero(parseInt(lefttime%60));$(".count").html(`活动倒计时<code>${d}</code>天<code>${h}</code>时<code>${m}</code>分<code>${s}</code>秒`);if(lefttime<=0){$(".Ji-col").hide();return}setTimeout(countDown,1000)}function checkCookie(){var viplogin_show=Cookies.get('viplogin_dontshow');if(viplogin_show==""||viplogin_show==null){$(".Ji-row").show();countDown()}else{$(".Ji-row").hide()}}$(document).ready(function(){$(".vip-login-title").html(viptitle);$(".vip-login-subtitle").html(vipsubtitle);$(".vip-login-btn").html(payvip);$(".vip-login-close").click(function(){$(".Ji-row").hide();Cookies.set('viplogin_dontshow','1',{expires:displaytime})});checkCookie();})
</script>
<div class="Ji-row"><style>@media(max-width:800px){.Ji-col{display:none}}.vip-login-tip{position:relative;box-sizing:border-box;padding:18px 10px 22px 20px;width:400px;height:175px;border-radius:var(--main-radius);background-color:var(--main-bg-color);background-position:right 50%;background-repeat:no-repeat;background-size:130px;box-shadow:0 0 30px rgba(0,0,0,.1);box-shadow:0px 0px 8px rgba(255,112,173,0.35)}.vip-login-countdown-row{display:flex;align-items:center}.vip-login-countdown-row i{color:var(--header-color);font-size:18px}.vip-login-countdown-row.countdown-lable{margin:0 3px 0 4px;font-size:14px;line-height:16px}.vip-login-countdown-row.counddown-wrap{font-size:14px}.vip-login-title{width:218px;margin:10px 0;font-weight:600;font-size:16px;line-height:22px;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;text-overflow:-o-ellipsis-lastline;text-overflow:ellipsis;word-break:break-word!important;word-break:break-all;line-break:anywhere;-webkit-line-clamp:1}.vip-login-subtitle{width:218px;color:var(--text2);font-size:14px;line-height:20px;display:-webkit-box;color:#8e8e8e;overflow:hidden;-webkit-box-orient:vertical;text-overflow:-o-ellipsis-lastline;text-overflow:ellipsis;word-break:break-word!important;word-break:break-all;line-break:anywhere;-webkit-line-clamp:1}.vip-login-btn{margin-top:10px;display:inline-block;height:40px;width:160px;line-height:40px;text-align:center;border-radius:8px;color:#fff;background-color:#00b2ff;transition:background-color.3s,color.3s;font-weight:600;cursor:pointer}.vip-login-close{position:absolute;width:15px;top:5px;right:5px;cursor:pointer}.Ji-row{position:fixed;bottom:30px;right:80px;z-index:10;display:none}.vip-login-countdown-row.counddown-wrap span{display:inline-block;margin:0px 4px;width:20px;font-size:13px;height:18px;color:var(--header-color);border-radius:5px;text-align:center;line-height:18px;font-weight:500px;background:var(--header-color)}</style><div class="Ji-col"><div class="vip-login-tip"><div class="vip-login-countdown-row"><div class="counddown-wrap"><p class="count"></p></div></div><div class="vip-login-title"></div><div class="vip-login-subtitle"></div><div><a href="<?php echo FACG('hddjs_text_5',false);?>"class="vip-login-btn pay-vip"></a></div><div class="vip-login-close"><svg class="ic-close"viewBox="0 0 1024 1024"><path d="M573.44 512.128l237.888 237.696a43.328 43.328 0 0 1 0 59.712 43.392 43.392 0 0 1-59.712 0L513.728 571.84 265.856 819.712a44.672 44.672 0 0 1-61.568 0 44.672 44.672 0 0 1 0-61.568L452.16 510.272 214.208 272.448a43.328 43.328 0 0 1 0-59.648 43.392 43.392 0 0 1 59.712 0l237.952 237.76 246.272-246.272a44.672 44.672 0 0 1 61.568 0 44.672 44.672 0 0 1 0 61.568L573.44 512.128z"></path></svg></div></div></div></div> 
<?php }}add_action('wp_footer', 'hddjs' );



/*
* ------------------------------------------------------------------------------
* 顶部美化
* ------------------------------------------------------------------------------
*/

//新年网站对联
function duilian(){ if (FACG('duilian', false)) { ?>
    <SCRIPT language="JavaScript">lastScrollY = 0;function heartBeat(){var diffY;if (document.documentElement && document.documentElement.scrollTop)diffY = document.documentElement.scrollTop;else if (document.body)diffY = document.body.scrollTopelsepercent=.1*(diffY-lastScrollY);if(percent>0)percent=Math.ceil(percent);else percent=Math.floor(percent);document.getElementById("leftDiv").style.top = parseInt(document.getElementById("leftDiv").style.top)+percent+"px";document.getElementById("rightDiv").style.top = parseInt(document.getElementById("rightDiv").style.top)+percent+"px";lastScrollY=lastScrollY+percent;}function close_left2(){left2.style.visibility='hidden';}function close_right2(){right2.style.visibility='hidden';}document.writeln("<style type=\"text\/css\">");document.writeln("#leftDiv,#rightDiv{position:absolute;}");document.writeln(".itemFloat{width:100px;height:auto;line-height:5px}");document.writeln("<\/style>");document.writeln("<div id=\"leftDiv\" style=\"top:112px;left:50px\">");document.writeln("<div id=\"left2\" class=\"itemFloat\">");document.writeln("<img border=0 src=<?php echo FACG('duilian_img_1',false);?>>");document.writeln("<br><a href=\"javascript:close_left2();\" title=\"关闭上面的对联\">×<\/a>");document.writeln("<\/div>");document.writeln("<\/div>");document.writeln("<div id=\"rightDiv\" style=\"top:112px;right:50px\">");document.writeln("<div id=\"right2\" class=\"itemFloat\">");document.writeln("<img border=0 src=<?php echo FACG('duilian_img_2',false);?>>");document.writeln("<br><a href=\"javascript:close_right2();\" title=\"关闭上面的对联\">×<\/a>");document.writeln("<\/div>");document.writeln("<\/div>");</SCRIPT>
<?php }}add_action('wp_footer', 'duilian' );

//网站动态标题
function title(){ if (FACG('title', false)) { ?>
    <script>var OriginTitile = document.title,titleTime;document.addEventListener("visibilitychange",function() {if (document.hidden) {document.title = "<?php echo FACG('title_text_2',false);?>";clearTimeout(titleTime)} else {document.title = "<?php echo FACG('title_text_1',false);?>" ;titleTime = setTimeout(function() {document.title = OriginTitile},2000)}});</script>
<?php }}add_action('wp_footer', 'title');

//顶部彩色进度条
function jindutiao(){ if (FACG('jindutiao', false)) { ?>
<style>#percentageCounter{position:fixed; left:0; top:0; height:3px; z-index:99999; background-image: linear-gradient(to right, #339933,#FF6666);border-radius:5px;}</style>
<script>$('head').before('<div id="percentageCounter"></div>');$(window).scroll(function() {var a = $(window).scrollTop(),c = $(document).height(),b = $(window).height();scrollPercent = a / (c - b) * 100;scrollPercent = scrollPercent.toFixed(1);$("#percentageCounter").css({width: scrollPercent + "%"});}).trigger("scroll");</script>
<?php }}add_action('wp_footer', 'jindutiao' );

//元旦灯笼
function chunjie(){ if (FACG('chunjie', false)) { ?>
<link rel="stylesheet" href="<?php echo FACG('static_FACG');?>/css/yuandan.css">
<script src="<?php echo FACG('static_FACG');?>/js/yuandan.js"></script>
<?php }}add_action('wp_footer', 'chunjie' );

//年兽
function nianshou(){ if (FACG('nianshou', false)) { ?>
<style>@media screen and (min-width: 850px){
    .NewYear {
        width: 260px;
        height: 300px;
        display: inline-block;
        background: url(<?php echo FACG('nianshou_img',false);?>) no-repeat 50%/50%;
        vertical-align: middle;
        position: fixed;
        left: 85.8%;
        top: 0px;
        z-index: 999;
        cursor: pointer;
        animation: new-year 1.2s ease-in-out 0s infinite alternate;
        margin-left: -1px;
        transform-origin: 50% 0;
        pointer-events: none;
    }
    }
    @keyframes new-year{
      0% {
        transform: rotate(10deg);
    }
      100%{
                transform: rotate(-10deg);
      }
    }</style>
<div class="NewYear"></div>
<?php }}add_action('wp_footer', 'nianshou' );

//幻灯片指示器优化
function swiper(){ if (FACG('swiper', false)) { ?>
<style>.swiper-button-next, .swiper-button-prev{height: 70px !important;}.swiper-button-prev{border-top-right-radius: 8px;border-bottom-right-radius: 8px;}.swiper-button-next{border-top-left-radius: 8px;border-bottom-left-radius: 8px;}</style>
<?php }}add_action('wp_footer', 'swiper' );

//文章&美化

/*
* ------------------------------------------------------------------------------
* 文章功能
* ------------------------------------------------------------------------------
*/

//文章底部添加过期提示
if (FACG('posts_gqts')) {
function FACG_article_time_update() { 

	$posts_gqts_sz = FACG('posts_gqts_sz');
	$date = get_the_modified_time('Y-m-d H:i:s');
	$content= '
		<div class="article-timeout">
			<strong>
				<i class="fa fa-bell" aria-hidden="true"></i> 温馨提示：
			</strong>本文最后更新于<code>'. $date .'</code>，' .$posts_gqts_sz['text']. '
		</div>
		<style>
			.article-timeout{position:relative; border-radius: 8px; position: relative; margin-bottom: 25px; padding: 10px; background-color: var(--body-bg-color);}
		</style>
	';

	echo $content;
 } add_action('zib_posts_content_after', 'FACG_article_time_update');
}

/*
* ------------------------------------------------------------------------------
* 页面美化
* ------------------------------------------------------------------------------
*/

//文章阴影边缘
function article_box_shadow(){ if (FACG('article_box_shadow', false))
{ 
if (is_single()) {?>
    <style>
            .article {
                border-radius: var(--main-radius);
                box-shadow: 1px 1px 3px 3px <?php echo FACG('article_box_shadow_ys1');?>;
            }

            .article:hover {
                box-shadow: 1px 1px 5px 5px <?php echo FACG('article_box_shadow_ys2');?>;
            }
        </style>
<?php }}}add_action('wp_footer', 'article_box_shadow' );

//文章标题鼠标悬停划线
function xthx(){ if (FACG('xthx', false)) { ?>
<style>
.posts-item .item-heading>a{background:linear-gradient(to right,#ec695c,#61c454) no-repeat right bottom;background-size:0 2px;transition:background-size 1300ms}.posts-item .item-heading>a:hover{background-position-x:left;background-size:100% 5px}
.article-title>a{background:linear-gradient(to right,#ec695c,#61c454) no-repeat right bottom;background-size:0 2px;transition:background-size 1300ms}.article-title>a:hover{background-position-x:left;background-size:100% 5px}
.zib-widget .text-ellipsis>a{background:linear-gradient(to right,#ec695c,#61c454) no-repeat right bottom;background-size:0 2px;transition:background-size 1300ms}.zib-widget .text-ellipsis>a:hover{background-position-x:left;background-size:100% 5px}
.zib-widget .text-ellipsis-2>a{background:linear-gradient(to right,#ec695c,#61c454) no-repeat right bottom;background-size:0 2px;transition:background-size 1300ms}.zib-widget .text-ellipsis-2>a:hover{background-position-x:left;background-size:100% 5px}</style>
<?php }}add_action('wp_footer', 'xthx' );

//文章内页彩色标签
function label(){ if (FACG('after', false)) { ?>
    <style>.article-tags{margin-bottom: 10px}.article-tags a{padding: 4px 10px;background-color: #19B5FE;color: white;font-size: 12px;line-height: 16px;font-weight: 400;margin: 0 5px 5px 0;border-radius: 2px;display: inline-block}.article-tags a:nth-child(5n){background-color: #4A4A4A;color: #FFF}.article-tags a:nth-child(5n+1){background-color: #ff5e5c;color: #FFF}.article-tags a:nth-child(5n+2){background-color: #ffbb50;color: #FFF}.article-tags a:nth-child(5n+3){background-color: #1ac756;color: #FFF}.article-tags a:nth-child(5n+4){background-color: #19B5FE;color: #FFF}.article-tags a:hover{background-color: #1B1B1B;color: #FFF}</style>
<?php }}add_action('wp_footer', 'label');

//小标题美化
function subtitle(){ if (FACG('subtitle', false)) { 
?>
    <script>
    var elements = document.getElementsByClassName("wp-block-heading");
for (var i = 0; i < elements.length; i++) {
    var element = elements[i];
    element.removeAttribute("class");
}

</script>
    <style>
        .zib-widget>h3:before,.wp-posts-content>h3.has-text-align-center:before, .wp-posts-content>h3:not([class]):before{content: '';position: absolute;top: 2px;left: 0;width: 20px!important;height: 20px!important;background: url(<?php echo FACG('subtitle_h3',false);?>) no-repeat center;box-shadow: none;background-size: 100% !important;}.zib-widget>h2:before,.wp-posts-content>h2.has-text-align-center:before, .wp-posts-content>h2:not([class]):before{content: '';position: absolute;top: 0;left: 0;width: 20px;height: 20px;background: url(<?php echo FACG('subtitle_h2',false);?>) no-repeat center;box-shadow: none;}.wp-posts-content h2:before{content: '';position: absolute;top: 0;left: 0;width: 20px;height: 20px;background: url(<?php echo FACG('subtitle_h2',false);?>) no-repeat center;box-shadow: none;}.wp-posts-content h3:before{content: '';position: absolute;top: 2px;left: 0;width: 20px!important;height: 20px!important;background: url(<?php echo FACG('subtitle_h3',false);?>) no-repeat center;box-shadow: none;background-size: 100% !important;}.wp-posts-content>h2.has-text-align-center, .wp-posts-content>h2:not([class]),.zib-widget>h2{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}.wp-posts-content h2{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}.wp-posts-content>h3.has-text-align-center, .wp-posts-content>h3:not([class]),.zib-widget>h3{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}.wp-posts-content h3{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}.h2:before{content: '';position: absolute;top: 0;left: 0;width: 20px;height: 20px;background: url(<?php echo FACG('subtitle_h2',false);?>) no-repeat center;box-shadow: none;},h2{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}.h2{color: var(--main);font-size: 18px;line-height: 24px;margin-bottom: 18px;position: relative;padding: 0 15px 0 28px;}</style>
        <script>
    var elements = document.getElementsByClassName("wp-block-heading");
for (var i = 0; i < elements.length; i++) {
    var element = elements[i];
    element.removeAttribute("class");
}

</script>
<script>
    var elements = document.getElementsByClassName("wp-block-heading");
for (var i = 0; i < elements.length; i++) {
    var element = elements[i];
    element.removeAttribute("class");
}

</script>
<?php }}add_action('wp_footer', 'subtitle' );

/*
* ------------------------------------------------------------------------------
* 评论美化
* ------------------------------------------------------------------------------
*/

//评论背景图添加快来说点啥
function comment_back(){ if (FACG('comment_back', false)) { ?>
    <style>textarea#comment {background-color:transparent;background:linear-gradient(rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05)),url(<?php echo FACG('comment_back_img',false);?>) right 10px bottom 10px no-repeat;-moz-transition:ease-in-out 0.45s;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}textarea#comment:focus {background-position-y:789px;-moz-transition:ease-in-out 0.45s;-webkit-transition:ease-in-out 0.45s;-o-transition:ease-in-out 0.45s;-ms-transition:ease-in-out 0.45s;transition:ease-in-out 0.45s;}</style>
<?php }}add_action('wp_footer', 'comment_back');

//评论区背景
function facg_comment_back(){ if (FACG('facg_comment_back', false)) { ?>
    <style>
	
/*定义日夜间颜色*/
body{
	--acg-color:#fff8fa;
	--acg-color2:#f8fdff;}
.dark-theme{
	--acg-color:#323335;
	--acg-color2:#323335;}
	
/*第一条评论样式*/
#postcomments .commentlist .comment{
	border-top:1px solid rgb(50 50 50 / 0%);
	border-radius:15px;margin:0 15px 15px;
	border:1px solid;
	display:flow-root;
	background-image:url(<?php echo FACG('facg_comment_back_img',false);?>);
	border-color:#71baff80;
	background-color:var(--acg-color2);}

/* 修改子比主题评论区默认样式 */
#postcomments .commentlist .comment+.comment{
	border-top:1px solid rgb(50 50 50 / 0%); /* 顶部边框设置为1像素宽，颜色为50%不透明度的黑色 */ 
	padding:0 0 15px 0; /* 内边距设置为0 0 15px 0，意味着上下左右分别是0、0、15px和0 */
	border-radius:15px; /* 设置边框半径为15像素，使边框呈现圆角效果 */
	margin:0 15px 15px; /* 外边距设置为0 15px 15px，意味着上下左右分别是0、15px、15px和默认值 */
	border:1px solid; /* 设置边框宽度为1像素，颜色为默认值（通常是黑色） */
	display:flow-root; /* 设置元素的显示类型为flow-root，这是一个新的CSS显示值，允许元素创建新的格式化上下文，同时保持其在文档流中的位置 */ 
	padding:10px;} /* 内边距设置为10px，意味着上下左右都是10px，这个属性会覆盖上面已经定义过的padding属性 */
	
/* 选择所有在#postcomments下的.commentlist里的.comment元素后面的同级元素，并选择其中序号为奇数的元素 */
#postcomments .commentlist .comment+.comment:nth-child(odd){
	background-image:url(<?php echo FACG('facg_comment_back_img2',false);?>); /* 将背景图像设置为粉色星星 */
	border-color:#ff8bb5; /* 将边框颜色设置为#ff8bb5粉红色 */
	background-color:var(--acg-color);} /* 将背景颜色设置为一个变量(--acg-color)，这个变量是我们最开始设置的日夜间背景色 */

/* 选择所有在#postcomments下的.commentlist里的.comment元素后面的同级元素，并选择其中序号为偶数的元素 */
#postcomments .commentlist .comment+.comment:nth-child(even){
	background-image:url(<?php echo FACG('facg_comment_back_img',false);?>); /* 将背景图像设置为蓝色星星 */
	border-color:#71baff80; /* 将边框颜色设置为#71baff80淡蓝色 */
	background-color:var(--acg-color2);} /* 将背景颜色设置为一个变量(--acg-color2)，之前我们设置的日夜间颜色 */

/*从上面我们能够了解到评论美化的基础，那么就可以直接开始评论回复的美化*/
#postcomments .children{
	background:rgb(116 116 116 / 0%);
	margin-bottom:6px;
	border-radius:15px;
	display:flow-root;}

#postcomments .children:nth-child(even){
	background-image:url(<?php echo FACG('facg_comment_back_img',false);?>);
	border-color:#71baff80;}

#postcomments .children:nth-child(odd){
	background-image:url(<?php echo FACG('facg_comment_back_img2',false);?>);
	border-color:#ff8bb5;
	background-color:var(--acg-color);}
        </style>
<?php }}add_action('wp_footer', 'facg_comment_back');

//首页评论美化
function index_comments(){ if (FACG('index_comments', false)) { ?>
	<style>
	   .comment-mini-lists>div.posts-mini{border: 1px dashed #999999;border-radius: 10px;margin-top: 10px;}
	</style>
<?php }}add_action('wp_footer', 'index_comments');

// 评论区ID
function comment_uid($info, $comment, $depth) {?>
<style>.bili-dyn-item__ornament{position:sticky;right:48px;top:18px;margin-top:-13px;float:right;}.bili-dyn-ornament__type--3{height:44px;width:146px;}.bili-dyn-ornament img{height:100%;width:100%;user-select: none;pointer-events: none;}.bili-dyn-ornament__type--3 span{font-family:num !important;font-size:12px;position:absolute;right:54px;top:15px;transform:scale(.88);transform-origin:right;}</style>
<?php

    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';  
    $randomString = '';  
    for ($i = 0; $i < 10; $i++) { // 生成10个随机字符  
        $randomString .= $characters[rand(0, strlen($characters) - 1)];  
    }
    $img_list = array( '/wp-content/plugins/FACG/img/uid/?kid=' . base64_encode($randomString));
    $color_list = array("rgb(138, 154, 247)", "rgb(187, 103, 138)","rgb(166, 236, 149)","rgb(172, 170, 94)","rgb(240, 88, 88)","rgb(182, 117, 243)","rgb(219, 96, 157)","rgb(245, 107, 72)","rgb(196, 167, 104)","rgb(221, 42, 42)","rgb(240, 158, 226)","rgb(243, 200, 98)","rgb(248, 155, 200)","rgb(114, 153, 238)","rgb(214, 207, 107)","rgb(192, 127, 235)","rgb(197, 184, 30)","rgb(245, 155, 210)","rgb(231, 197, 152)","rgb(98, 98, 119)","rgb(221, 200, 173)","rgb(110, 175, 187)","rgb(137, 141, 190)","rgb(166, 152, 238)","rgb(104, 192, 207)","rgb(216, 124, 152)");
    $img_res=array_rand($img_list);
    $color_res=array_rand($color_list);
    $uid_type = $comment->user_id; 
    $uid_type_desc = 'ID'; 
    $bill_html = '<div class="bili-dyn-item__ornament" data-clipboard-tag="'.$uid_type_desc.'"><div class="bili-dyn-ornament"><div class="bili-dyn-ornament__type--3"><img  src="' . $img_list[$img_res]. '" alt="'.$uid_type_desc.'"><span style="color:' . $color_list[$color_res] . '"><b>ID:'.str_pad($uid_type,FACG('comment_uid_s'),"0",STR_PAD_LEFT).'</b></span></div></div></div>';
    $info = $info .$bill_html;
if (FACG('comment_uid')) {
    return $info;}
}
add_filter('comment_footer_info', 'comment_uid', 10, 3);

//评论区背景
function facg_comment_blue(){ if (FACG('facg_comment_blue', false)) { ?>
    <style>
    /*评论美化 - 蓝色款*/
body{
    --acg-color:#f8fdff;
}
.dark-theme{
    --acg-color:#323335;
}
#postcomments .children {
    background: rgb(116 116 116 / 0%);
}
.comment .list-inline>.comt-main {
    border-color: #71baff80;
    background-color: var(--acg-color);
    background-image: url(<?php echo FACG('facg_comment_blue_img',false);?>);
}
.comment .list-inline>li {
    vertical-align: top;
    overflow: hidden;
    border-radius: 5px;
    margin: 0 15px 15px;
    border: 1px solid;
    position: relative;
    display: flow-root;
    padding: 10px;
}
        </style>
<?php }}add_action('wp_footer', 'facg_comment_blue');

//评论区背景
function facg_comment_red(){ if (FACG('facg_comment_red', false)) { ?>
    <style>
    /*评论美化 - 红色款*/
body{
    --acg-color:#fff8fa;
}
.dark-theme{
    --acg-color:#323335;
}
#postcomments .children {
    background: rgb(116 116 116 / 0%);
}
.comment .list-inline>.comt-main {
    border-color: #ff8bb5;
    background-color: var(--acg-color);
    background-image: url(<?php echo FACG('facg_comment_red_img',false);?>);
}
.comment .list-inline>li {
    vertical-align: top;
    overflow: hidden;
    border-radius: 5px;
    margin: 0 15px 15px;
    border: 1px solid;
    position: relative;
    display: flow-root;
    padding: 10px;
}
        </style>
<?php }}add_action('wp_footer', 'facg_comment_red');

//评论小工具
function plxgj(){ if (FACG('plxgj', false)) { ?>
<style>.comment-mini-lists>div.posts-mini{box-shadow:0px 0px 8px <?php echo FACG('plxgj_ys',false);?>;border-radius:10px;margin-top:10px;}</style>
<?php }}add_action('wp_footer', 'plxgj');

//侧边栏评论小工具
function cblplxgj(){ if (FACG('cblplxgj', false)) { ?>
<style>.posts-mini{background-size:cover;margin-bottom:5px;padding:15px;}span.flex0.icon-spot.muted-3-color{color:var(--theme-color);opacity:0.5;}.text-ellipsis-5{max-height:3em;-webkit-line-clamp:5;max-width:12em;}</style>
<script>
var postsMiniElements = document.querySelectorAll('.posts-mini');  
postsMiniElements.forEach(function(element) {  
    var randomBase64 = btoa(Math.random().toString(36).substr(2, 9));  
    var url = '/wp-content/plugins/FACG/img/uid/?kid=' + randomBase64;  
    element.style.backgroundImage = 'url(' + url + ')';  
});
</script>
<?php }}add_action('wp_footer', 'cblplxgj');

/*
* ------------------------------------------------------------------------------
* 列表美化
* ------------------------------------------------------------------------------
*/

//上悬浮底部伴有粉色跳跳
function articlefloat(){ if (FACG('articlefloat', false)) { ?>
    <style>@media screen and (min-width: 980px){.posts-item:not(article){transition: all 0.3s;}.posts-item:not(article):hover{transform: translateY(-10px); box-shadow: 0 8px 10px <?php echo FACG('articlefloat_color',false);?>;}}</style>
<?php }}add_action('wp_footer', 'articlefloat');

//晃动样式悬浮
function postfloat(){ if (FACG('postfloat', false)) { ?>
    <style>.posts-item:not(article):hover{opacity: 1;z-index: 99;border-radius: 20px;transform: translateY(-5px);box-shadow: 0 3px 20px <?php echo FACG('postfloat_color',false);?>;animation: index-link-active 1s cubic-bezier(0.315, 0.605, 0.375, 0.925) forwards;}
	@keyframes index-link-active {0%{transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(0);}16%{transform: perspective(2000px) rotateX(10deg) rotateY(5deg) translateZ(32px);}100%{transform: perspective(2000px) rotateX(0) rotateY(0) translateZ(65px);}}</style>
<?php }}add_action('wp_footer', 'postfloat');

//文章卡片果冻弹跳特效
function wzkpjumps(){ if (FACG('wzkpjumps', false)) { ?>
    <style>.posts-item:not(article):hover{animation: jumps-data-v-6bdef187 1.2s ease 1;}
@keyframes jumps-data-v-6bdef187{
0% {
	transform: translate(0);
}
10% {
	transform: translateY(5px) scaleX(1.2) scaleY(.8);
}
30% {
	transform: translateY(-13px) scaleX(1) scaleY(1) rotate(5deg);
}
50% {
	transform: translateY(0) scale(1) rotate(0);
}
55% {
	transform: translateY(0) scaleX(1.1) scaleY(.9) rotate(0);
}
70% {
	transform: translateY(-4px) scaleX(1) scaleY(1) rotate(-2deg);
}
80% {
	transform: translateY(0) scaleX(1) scaleY(1) rotate(0);
}
85% {
	transform: translateY(0) scaleX(1.05) scaleY(.95) rotate(0);
}
100% {
	transform: translateY(0) scaleX(1) scaleY(1);
  }
}</style>
<?php }}add_action('wp_footer', 'wzkpjumps');

//文章列表悬停萝莉
function post_ll(){ if (FACG('post_ll', false)) { ?>
    <style>
    /*首页文章列表悬停可爱萝莉*/
@media screen and (min-width:980px) {
.tab-content .posts-row>*:hover {
    transition:all <?php echo FACG('post_ll_s',false);?>s;
    content: " ";
    right: -50px;
    background-size: contain;
    background-position: center right;
    background-image: url(<?php echo FACG('post_ll_img',false);?>);
    background-repeat: no-repeat;
}
}
        </style>
<?php }}add_action('wp_footer', 'post_ll');

//文章卡片模式排列
function wzcard(){ if (FACG('wzcard',false)) {?>
    <style>
    @media only screen and (min-width: 1200px){.posts-item.card {
                width: calc(<?php echo 100.000000/FACG('wzcard_num');?>% - <?php echo 80/FACG('wzcard_num');?>px);
            }}
    </style>
<?php }}add_action('wp_footer', 'wzcard');

// 文章置顶+新文章发布ICON图标
function FACG_post_newicon($post){ ?> 
    <style>
    .posts-item{position: relative !important;}
    .FACG-new-icon{position: absolute;height: 35px;right: 0;top: 0;}
    .FACG-new-icon img{-webkit-user-drag: none;}
    </style>
   <?php
    if (FACG('postICON', false)) {
    $wiui_date = date("Y-m-d H:i:s");
    $wiui_post_date = get_the_time('Y-m-d H:i:s', $post);
    $wiui_diff = (strtotime($wiui_date)-strtotime($wiui_post_date))/3600;
    if($wiui_diff<24){
        $wiui_new_icon = '<div class="FACG-new-icon"><img src="'. FACG('new_post_img') .'" draggable="false" alt="最新文章" /></div>';
    }else if (is_sticky()){
        $wiui_new_icon = '<div class="FACG-new-icon"><img src="'. FACG('post_img') .'" draggable="false" alt="置顶文章" /></div>';
    }else{
        $wiui_new_icon = '';
    }
    //开始输出
    return $wiui_new_icon;
}}

//文章卡片标题
function kapianbt(){ if (FACG('kapianbt', false)) { ?>
    <style>
	/*文章卡片标题*/
h2.item-heading {
    font-family: "Chango",cursive;
    color: <?php echo FACG('kapianbt_color',false);?>;
    text-align: center;
    background: url(<?php echo FACG('kapianbt_img',false);?>) no-repeat left center,url(<?php echo FACG('kapianbt_img2',false);?>) no-repeat right center;
    background-size: auto 10px;
    padding: 15px 5px;
}
.posts-item.card .item-heading {
    min-height: 3.8em;
}
.item-heading {  
    display: flex;  
    align-items: center;
}  
  
.focus-color {  
    display: flex;  
    flex-direction: column;
}
        </style>
<?php }}add_action('wp_footer', 'kapianbt');

//功能&设置

/*
* ------------------------------------------------------------------------------
* 维护模式
* ------------------------------------------------------------------------------
*/
