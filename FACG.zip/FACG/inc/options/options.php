<?php
/*
Plugin Name: FACG美化插件
Plugin URI: https://facg.top/
Description: 由枫影开发的子比主题美化插件，为子比主题提供更多的扩展功能。主题源码有详细的注释，支持二次开发。使用盗版主题会存在各种未知风险。支持正版，从我做起！
Version: 3.3
Author: 枫影
Author URI: https://facg.top/
*/

 //自定义css、js
function FACG_csf_add_custom_wp_enqueue()
{
    // Style
    @wp_enqueue_style('csf_custom_css',FACGurl.'/inc/csf-framework/assets/css/style.css',array(), '1');
    // Script
    @wp_enqueue_script('csf_custom_js',FACGurl. '/inc/csf-framework/assets/js/main.min.js', array('jquery'), '1');
}
add_action('csf_enqueue', 'FACG_csf_add_custom_wp_enqueue',1);
// 获取及设置主题配置参数
function _FACG($name, $default = false, $subname = '')
{
    //声明静态变量，加速获取
    static $zib_get_option = null;
    if ($zib_get_option) {
        $options = $zib_get_option;
    } else {
        $zib_get_option = get_option('FACG');
    }
    if (isset($options[$name])) {
        if ($subname) {
            return isset($options[$name][$subname]) ? $options[$name][$subname] : $default;
        } else {
            return $options[$name];
        }
    }
    return $default;
}

function _FACG1($name, $value)
{
    $get_option        = get_option('FACG');
    $get_option        = is_array($get_option) ? $get_option : array();
    $get_option[$name] = $value;
    return update_option('FACG', $get_option);
}

//获取及设置压缩后的posts_meta
if (!function_exists('of_get_posts_meta')) {
    function of_get_posts_meta($name, $key, $default = false, $post_id = '')
    {
        global $post;
        $post_id  = $post_id ? $post_id : $post->ID;
        $get_mate = get_post_meta($post_id, $name, true);
        if (isset($get_mate[$key])) {
            return $get_mate[$key];
        }
        return $default;
    }
}

if (!function_exists('of_set_posts_meta')) {
    function of_set_posts_meta($post_id = '', $name, $key, $value)
    {
        if (!$name) {
            return false;
        }
        global $post;
        $post_id        = $post_id ? $post_id : $post->ID;
        $get_mate       = get_post_meta($post_id, $name, true);
        $get_mate       = (array) $get_mate;
        $get_mate[$key] = $value;
        return update_post_meta($post_id, $name, $get_mate);
    }
}