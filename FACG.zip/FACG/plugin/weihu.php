<?php
// 网站维扩护503代码
if(!is_admin() && (FACG('is_maintenance'))){
	
	add_action('wp_loaded', function (){
		global $pagenow;

		if (current_user_can('manage_options')  || $pagenow == 'wp-login.php' || $_SERVER['REQUEST_URI'] == "/user-sign?tab=signin&redirect_to") {
			return;
		}
		
		header( $_SERVER["SERVER_PROTOCOL"] . ' 503 Service Temporarily Unavailable', true, 503 );
		header('Content-Type:text/html;charset=utf-8');

		require FACG_TEMPLATE_DIRECTORY_URI.'/plugin/xyindex.php';

		exit;
	});
}

//倦意网站维护
$fullUrl = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
if(FACG('JUANYI_MTCE_SETTING_OPEN') == '1' && $fullUrl != wp_login_url()){
	add_action('wp_loaded', function (){
	    if(!current_user_can( 'manage_options' )){
	        header( $_SERVER["SERVER_PROTOCOL"] . ' '.FACG('JUANYI_MTCE_SETTING_STATUS'));
		    header('Content-Type:text/html;charset=utf-8');
		    require_once FACG_TEMPLATE_DIRECTORY_URI.'/plugin/jyindex.php';
    
		    exit;
	    }
	});
}