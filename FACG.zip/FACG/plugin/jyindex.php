<?php
if (! defined('ABSPATH')) {
	die;
}
$current_time = current_time( 'timestamp' );
$target_time = strtotime(FACG('JUANYI_MTCE_SETTING_TIME'));
$left_time = ($target_time - $current_time )/60;
if($left_time > 60){
    $left_time = floor($left_time / 60)." 时 ".($left_time % 60)." 分";
}else{
    $left_time = floor($left_time)." 分";
}

if ( $current_time > $target_time ) { 
    $left_time = '等待管理员关闭维护模式...';
}
?>
<html lang="zh-CN"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width">
		<meta name="robots" content="noindex, nofollow">
	<title><?php echo FACG('JUANYI_MTCE_SETTING_TITLE')?> - <?php echo get_bloginfo('name');?></title>
	<style type="text/css">
		html {
			background: #f1f1f1;
		}
		body {
			margin:0;
			color: #444;
			font-family: "微软雅黑";
			background-color: #f5f5f5;
            text-align: center;
			width:100%;
			height:100%;
		}
		h1 {
			border-bottom: 1px solid #dadada;
			clear: both;
			color: #666;
			font-size: 24px;
			margin: 30px 0 0 0;
			padding: 0;
			padding-bottom: 7px;
		}
		
		.juanyi_mtce {
			margin:200px 0px;
			font-size: 14px;
			line-height: 1.5;
		}
		.juanyi_button {
			background: #f3f5f6;
			border: 1px solid #016087;
			color: #016087;
			display: inline-block;
			text-decoration: none;
			font-size: 13px;
			line-height: 2;
			height: 28px;
			margin: 0;
			padding: 0 10px 1px;
			cursor: pointer;
			-webkit-border-radius: 3px;
			-webkit-appearance: none;
			border-radius: 3px;
			white-space: nowrap;
			-webkit-box-sizing: border-box;
			-moz-box-sizing:    border-box;
			box-sizing:         border-box;
			vertical-align: top;
		}
		.juanyi_buttons_container>.juanyi_button {
            margin: 0 5px;
        }
        .footer{
            width: 100%;
            position:fixed;
            bottom: 5px;
        }
		.footer>a{
		    font-size:14px;
			color:#016087;
		    text-decoration:none;
		}
        <?php 
        echo FACG('JUANYI_MTCE_SETTING_EXTRA');
        if(FACG('JUANYI_MTCE_SETTING_CONTACT_QQQUN') == "0"){
            echo '
                .qqqun {
                    display:none;
                }
            ';
        }
        if(FACG('JUANYI_MTCE_SETTING_CONTACT_TG') == "0"){
            echo '
                .tg {
                    display:none;
                }
            ';
        }
        ?>
	</style>
</head>
<body>
	<br/>
	<div class="juanyi_mtce">
        <svg t="1702785712519" style="width: 80px;height:80px;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4403" width="200" height="200"><path d="M910.912 291.136l-45.824 46.016c-48.832 49.024-128.32 49.024-177.152 0s-48.832-128.832 0-177.856l45.824-46.016c25.28-25.408 8.384-55.296-37.184-48.192a228.224 228.224 0 0 0-126.72 64.576 231.04 231.04 0 0 0-62.144 210.624l-384.32 385.92a126.208 126.208 0 0 0 0 177.792 124.992 124.992 0 0 0 177.088 0l384.384-385.92a229.12 229.12 0 0 0 274.048-189.568c7.104-45.76-22.656-62.784-48-37.376z m-669.44 553.536c-16.32 16.384-42.752 16.384-59.072 0s-16.32-42.88 0-59.264a41.856 41.856 0 0 1 59.072 59.264z m-41.728-545.856L344.448 444.16l59.072-59.264-144.704-145.344-32.448-62.208-103.296-74.112L64 162.496 137.792 266.24l61.952 32.576z m484.288 308.288a20.8 20.8 0 0 0-29.504 0l-88.576 88.96a21.056 21.056 0 0 0 0 29.632l208.96 209.792c32.64 32.704 85.568 32.704 118.144 0 32.64-32.704 32.64-85.824 0-118.592l-209.024-209.792z" p-id="4404"></path></svg><h1><?php echo FACG('JUANYI_MTCE_SETTING_TITLE')?></h1>
            <p>预计剩余时间：<?php echo $left_time?></p>
            <p><?php echo FACG('JUANYI_MTCE_SETTING_SUBTITLE')?></p>
            <div class="juanyi_buttons_container">
                <a class="juanyi_button qqqun" href="<?php echo FACG('JUANYI_MTCE_SETTING_CONTACT_QQQUN_URL')?>"><svg t="1692542896120" style="margin-bottom: -3px;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7104" width="15" height="15"><path d="M173.056 947.712c0 41.984 73.728 76.288 164.352 76.288S501.76 989.696 501.76 947.712s-73.728-76.288-164.352-76.288-164.352 33.792-164.352 76.288zM521.728 947.712c0 41.984 73.728 76.288 164.352 76.288 91.136 0 164.352-34.304 164.352-76.288s-73.728-76.288-164.352-76.288c-90.624-0.512-164.352 33.792-164.352 76.288z" fill="#F5B824" p-id="7105"></path><path d="M878.08 506.88l-36.864-118.784C840.704 1.536 528.384 0 512 0c-16.896 0-328.704 1.536-328.704 388.096L145.92 506.88s-125.44 157.696-40.96 294.912c9.728 6.656 10.24 30.72 61.44-77.312 0 0 68.608 241.664 343.552 243.712h3.072c274.944-2.048 343.552-243.712 343.552-243.712 51.2 108.032 52.224 86.016 61.44 77.312 85.504-137.216-39.936-294.912-39.936-294.912z" fill="#121213" p-id="7106"></path><path d="M526.336 254.464c0 51.712 29.696 93.696 66.56 93.696s66.56-41.984 66.56-93.696c0-51.712-29.696-93.696-66.56-93.696-36.864 0.512-66.56 41.984-66.56 93.696zM355.328 254.464c0 51.712 29.696 93.696 66.56 93.696s66.56-41.984 66.56-93.696c0-51.712-29.696-93.696-66.56-93.696-36.352 0.512-66.56 41.984-66.56 93.696z" fill="#FFFFFF" p-id="7107"></path><path d="M414.72 254.464c0 22.016 12.8 40.448 28.672 40.448 15.872 0 28.672-17.92 28.672-40.448s-12.8-40.448-28.672-40.448c-15.872 0.512-28.672 18.432-28.672 40.448z" fill="#161616" p-id="7108"></path><path d="M781.312 466.944c-113.152 94.208-269.312 83.456-269.312 83.456s-156.672 10.752-269.312-83.456c0 0-107.52 484.864 269.312 484.864s269.312-484.864 269.312-484.864z" fill="#FAFAFB" p-id="7109"></path><path d="M840.704 388.096s-90.112 161.792-328.704 161.792-328.704-161.792-328.704-161.792C144.896 492.032 145.92 506.88 145.92 506.88c36.864 40.96 80.896 74.752 129.536 99.84-3.072 34.816-7.68 88.064-7.168 115.2 0.512 42.496 26.624 45.056 86.528 51.2 59.904 5.632 47.616-10.24 47.616-37.376V650.24c63.488 12.288 109.056 7.68 109.056 7.68s208.896 21.504 366.08-152.064c0.512 1.024 1.536-13.824-36.864-117.76z" fill="#D53118" p-id="7110"></path><path d="M687.616 407.552c-53.76-25.6-140.8-33.792-175.616-33.792s-121.856 8.192-175.616 33.792c-25.6 8.704-35.84 15.36-35.84 24.064 0 1.024 1.024 2.56 2.56 4.096 50.176 31.232 125.44 51.2 209.408 51.2s159.232-19.968 209.408-51.2c1.536-2.048 2.56-3.072 2.56-4.096-0.512-8.704-10.752-15.36-36.864-24.064z" fill="#F0B225" p-id="7111"></path></svg>QQ交流群</a>
                <a class="juanyi_button tg" href="<?php echo FACG('JUANYI_MTCE_SETTING_CONTACT_TG_URL')?>"><svg t="1692542667001" style="margin-bottom: -3px;" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4029" width="15" height="15"><path d="M512 512m-464 0a464 464 0 1 0 928 0 464 464 0 1 0-928 0Z" p-id="4030" data-spm-anchor-id="a313x.search_index.0.i0.4d8f3a81byJwZH" class="selected" fill="#1296db"></path><path d="M750.56 336l-77.28 364.8c-5.76 25.76-20.96 32-42.56 20l-117.76-86.72L456.16 688a29.76 29.76 0 0 1-23.68 11.52l8.48-119.84L659.04 384c9.6-8.48-1.92-13.12-14.72-4.8L374.56 548.32 258.56 512c-25.28-8-25.76-25.28 5.12-37.44l454.24-175.04c21.12-7.84 39.52 4.48 32.64 36.48z" fill="#FFFFFF" p-id="4031"></path></svg> TG交流群</a>
            </div>
        </div>
    <div class="footer">
        <a href="<?php echo wp_login_url()?>">管理登录</a>
	</div>
	</body></html>